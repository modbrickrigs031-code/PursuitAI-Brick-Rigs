@echo off
setlocal
if not exist "%~dp0Install-Alpha.ps1" goto NotExtracted
if not exist "%~dp0PursuitAI\Scripts\main.lua" goto NotExtracted
if not exist "%~dp0dependencies\UE4SS_v3.0.1-1176-g1ba38db4.zip" goto NotExtracted
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Alpha.ps1" -EnableLoader %*
set "PursuitAIExit=%ERRORLEVEL%"
if not "%PursuitAIExit%"=="0" echo FAILED. Read the error above.
pause
exit /b %PursuitAIExit%
:NotExtracted
echo PursuitAI installation files are missing.
echo You probably opened this CMD from INSIDE the ZIP archive.
echo 1. Close this window and the archive.
echo 2. Right-click the ZIP and select EXTRACT ALL.
echo 3. Open the extracted folder and run Install.cmd or Update.cmd there.
echo Keep PursuitAI, dependencies and all PS1 files together.
echo No game files were changed.
pause
exit /b 2
