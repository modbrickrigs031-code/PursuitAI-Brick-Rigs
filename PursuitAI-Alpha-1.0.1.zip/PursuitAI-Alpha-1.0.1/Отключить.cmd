@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Disable-Alpha.ps1"
set "PursuitAIExit=%ERRORLEVEL%"
if not "%PursuitAIExit%"=="0" echo FAILED. Read the error above.
pause
exit /b %PursuitAIExit%
