param([string]$GameRoot='',[string]$VehicleRoot=(Join-Path $env:LOCALAPPDATA 'BrickRigs\SavedRemastered\Vehicles'))
$ErrorActionPreference='Stop'
# Update and first install share one verified repair path, including loader and Mods creation.
& (Join-Path $PSScriptRoot 'Repair-Alpha.ps1') -GameRoot $GameRoot -VehicleRoot $VehicleRoot -EnableLoader
if (-not $?) { throw 'Update failed; see the error above.' }
