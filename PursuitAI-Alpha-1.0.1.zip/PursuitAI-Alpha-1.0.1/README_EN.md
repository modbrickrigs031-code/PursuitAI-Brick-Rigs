# MADE BY MR.HOGE
## PursuitAI Alpha 1.0.1 — first public alpha

Brick Rigs 1.11.7 / Windows x64. Single player and multiplayer hosted by a player. Experimental local driving AI; not full road navigation.

### Install / update
Close Brick Rigs. Extract the entire archive. Run Install.cmd for the first installation or Update.cmd to update. Both find the game in Steam libraries and create BrickRigs/Content/Mods and the required subfolders when missing. Update also works when the mod is not installed yet. Keep all archive folders together. Existing settings are preserved and backups are stored beside the installer. If Program Files access is denied, run the CMD as administrator. Do not copy only the ZIP into Mods: this Lua mod needs the included UE4SS loader. Restart the game after installation; F6/startup_status.txt must show Alpha 1.0.1.

English is the default language. F8 > Settings > Language selects English or Russian; the language is saved and applied immediately; the menu closes and reopens in the selected language. Reinforcements are OFF by default, including migration from settings without the new opt-in switch. To enable them, turn on the reinforcement checkbox before starting a new pursuit and set reserve/model weights.

### Alpha 1.0.1 fixes
- Russian/English changes rebuild the menu immediately without cancelling a running pursuit. No game restart is required for language changes.
- Free-path cruise defaults to 500 km/h; the UI and settings accept 30..500. Old unversioned speed settings migrate to 500 once; saving records the migration so later manual choices are preserved. Real vehicle performance, cornering and obstacle braking still apply.
- Running CMD directly inside a ZIP extracts only that file in Windows. The launcher now checks its companion files and displays Extract All instructions before starting PowerShell. Right-click the downloaded ZIP, choose Extract All, then run Update.cmd from the extracted folder.

### Tutorial
F8 opens the menu; the first tab contains an in-game tutorial.
1. Host: spawn a police vehicle, enter its driver seat, press F7 to mark it, then exit. Repeat for other police vehicles. Do not leave another player in a marked car.
2. Enter your getaway vehicle. Choose Me to chase yourself, or refresh the player list and select a friend seated in a vehicle.
3. Press F9 / Start pursuit. F10 stops the pursuit. F11 clears police marks. F8 closes the menu.
4. In multiplayer, only the host controls police. If the selected player exits their car, police wait; changing cars updates the target; disconnecting stops the pursuit.
5. Optional reinforcements replace disabled cars after wreck cleanup; they do not continuously increase the police count. Reserve is spent only after a replacement actually moves. Included source vehicle assets must be installed. Cameras/terrain can defer spawning.

### Changes for the public alpha
- A lined-up final ram uses the target's current position, retains the attacking cop briefly and bypasses last-second skid steering. Walls beyond the intended impact no longer cause a dodge; walls before it and other police retain collision checks. This reduces misses, not a guarantee of every hit.
- MR.HOGE's light bars use DisableSteering, not only Beacon/WarningLight. Police now activate all three channels and restore their original states on stop. The AI uses forced steering; a native test confirmed it keeps turning with this auxiliary channel enabled. A native screenshot now visibly shows the roof light bar and additional emergency lights on with an NPC driver. Different custom bindings may need adaptation.
- Both Manual and Automatic transmission modes are supported; the player's preference is read, never changed. Wall checks constrain prediction. Previous host self-target and replacement-spawning support is retained.

### Limits / verification
301 Lua checks passed; 42 Lua files passed syntax checks. Missing-Mods installation and repeated update were tested in a separate game-directory fixture with settings preservation. Native auxiliary-channel test: steering=0.70, changing yaw and vehicle speed while DisableSteering=true, followed by state restoration. The proof image and logs are in validation/. The final public build has not had a new two-client multiplayer test or exhaustive city chase test. Physical jams, collisions, wrong turns and crashes remain possible in an alpha. Do not describe this as stable or fully tested.

### Attribution and copying
MADE BY MR.HOGE. See LICENSE.txt. Original Lua code carries author credit and the archive contains SHA-256 checksums for detecting changes. Distributed Lua cannot be made impossible to copy; no DRM, hidden checks or claim of technical theft prevention is included. Third-party licenses remain separate. Use your official download page to establish the original release.

If a bug occurs, provide PursuitAI/runtime_trace.log, diagnostics.txt, startup_status.txt and UE4SS.log. For a crash include the newest SavedRemastered/Crashes folder. Report host/client roles, car model and game version.
