# Shared path discovery. This file does not change the game or Steam settings.
function Get-PursuitSteamCandidates {
    param([string[]]$SteamRoots)
    $libraries = @($SteamRoots)
    foreach ($steamRoot in $SteamRoots) {
        $vdf = Join-Path $steamRoot 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $vdf -PathType Leaf) {
            $content = [IO.File]::ReadAllText($vdf)
            foreach ($match in [regex]::Matches($content, '"path"\s*"([^"]+)"')) {
                $libraries += $match.Groups[1].Value.Replace('\\', '\')
            }
        }
    }
    foreach ($library in ($libraries | Where-Object { $_ } | Sort-Object -Unique)) {
        $candidate = Join-Path $library 'steamapps\common\Brick Rigs'
        if (Test-Path -LiteralPath (Join-Path $candidate 'BrickRigs\Binaries\Win64\BrickRigsSteam-Win64-Shipping.exe') -PathType Leaf) {
            [IO.Path]::GetFullPath($candidate).TrimEnd('\')
        }
    }
}

function Resolve-PursuitGameRoot {
    param([string]$GameRoot, [switch]$NoPrompt)
    $relativeExe = 'BrickRigs\Binaries\Win64\BrickRigsSteam-Win64-Shipping.exe'
    if (-not [string]::IsNullOrWhiteSpace($GameRoot)) {
        $resolved = [IO.Path]::GetFullPath($GameRoot.Trim().Trim('"')).TrimEnd('\')
        if (-not (Test-Path -LiteralPath (Join-Path $resolved $relativeExe) -PathType Leaf)) {
            throw "Brick Rigs executable not found in: $resolved"
        }
        return $resolved
    }
    $steamRoots = @()
    foreach ($registryPath in @('HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam', 'HKLM:\SOFTWARE\Valve\Steam')) {
        $properties = Get-ItemProperty -LiteralPath $registryPath -ErrorAction SilentlyContinue
        if ($properties.SteamPath) { $steamRoots += $properties.SteamPath }
        if ($properties.InstallPath) { $steamRoots += $properties.InstallPath }
    }
    if (${env:ProgramFiles(x86)}) { $steamRoots += Join-Path ${env:ProgramFiles(x86)} 'Steam' }
    $candidates = @(Get-PursuitSteamCandidates -SteamRoots ($steamRoots | Sort-Object -Unique) | Sort-Object -Unique)
    if ($candidates.Count -eq 1) { return $candidates[0] }
    if ($NoPrompt) { throw 'No unique Brick Rigs installation found. Pass -GameRoot explicitly.' }
    if ($candidates.Count -gt 1) {
        Write-Host 'Multiple installations found. Enter the full path of the one to use:'
        $candidates | ForEach-Object { Write-Host $_ }
    } else {
        Write-Host 'Brick Rigs not found automatically. In Steam: Manage > Browse local files.'
        Write-Host 'Enter the full game folder path (not the Mods folder):'
    }
    $answer = Read-Host 'Game folder (Enter to cancel)'
    if ([string]::IsNullOrWhiteSpace($answer)) { throw 'Cancelled. No game files changed.' }
    Resolve-PursuitGameRoot -GameRoot $answer -NoPrompt
}
