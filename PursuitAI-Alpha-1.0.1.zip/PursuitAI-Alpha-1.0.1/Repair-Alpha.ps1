param([string]$GameRoot = '',[switch]$EnableLoader,[string]$VehicleRoot=(Join-Path $env:LOCALAPPDATA 'BrickRigs\SavedRemastered\Vehicles'))
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Find-Game.ps1')
$GameRoot = Resolve-PursuitGameRoot -GameRoot $GameRoot
. (Join-Path $PSScriptRoot 'Vehicle-Assets.ps1')
function Hash([string]$Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
function Within([string]$Path,[string]$Root) {
    $full=[IO.Path]::GetFullPath($Path)
    $prefix=[IO.Path]::GetFullPath($Root).TrimEnd('\')+'\'
    if (-not $full.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)) { throw "Path outside intended directory: $full" }
    return $full
}
function Set-Ini([string]$Text,[string]$Section,[string]$Key,[string]$Value) {
    $pattern='(?ms)(^\['+[regex]::Escape($Section)+'\]\r?\n)(.*?)(?=^\[|\z)'
    $match=[regex]::Match($Text,$pattern)
    if (-not $match.Success) { return $Text.TrimEnd()+"`r`n`r`n[$Section]`r`n$Key = $Value`r`n" }
    $body=$match.Groups[2].Value
    $keyPattern='(?m)^\s*'+[regex]::Escape($Key)+'\s*=[^\r\n]*'
    if ([regex]::IsMatch($body,$keyPattern)) {
        $body=[regex]::Replace($body,$keyPattern,{param($m) "$Key = $Value"})
    } else { $body=$body.TrimEnd()+"`r`n$Key = $Value`r`n`r`n" }
    return $Text.Remove($match.Index,$match.Length).Insert($match.Index,$match.Groups[1].Value+$body)
}
$game=[IO.Path]::GetFullPath($GameRoot)
$win=Join-Path $game 'BrickRigs\Binaries\Win64'
$contentMods=Within (Join-Path $game 'BrickRigs\Content\Mods') $game
$exe=Join-Path $win 'BrickRigsSteam-Win64-Shipping.exe'
if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) { throw 'Brick Rigs executable not found.' }
if ((Hash $exe) -ne '87edbb13ac63bc56bb0fe24f4a260e45029014492537335517b7e88b07526603') {
    throw 'This repair is pinned to the inspected Brick Rigs 1.11.7 executable. No files changed.'
}
if (Get-Process -Name 'BrickRigsSteam-Win64-Shipping','BrickRigs' -ErrorAction SilentlyContinue) { throw 'Close Brick Rigs before applying the repair.' }
$archive=Join-Path $PSScriptRoot 'dependencies\UE4SS_v3.0.1-1176-g1ba38db4.zip'
if ((Hash $archive) -ne 'e615ee7a2c24344ea5aeef85183d6cfd550f4f6352225976679f9fefffd0b9a5') { throw 'Updated loader archive checksum mismatch.' }
$oldProxyArchive=Join-Path $PSScriptRoot 'dependencies\UE4SS_v3.0.1.zip'
if ((Hash $oldProxyArchive) -ne '4b47d4bceddd2f561a4e395bfa00924ccfc945af576a2d0c613e6537846c57ec') { throw 'Original proxy archive checksum mismatch.' }
$proxy=Join-Path $win 'dwmapi.dll'
if ((Test-Path -LiteralPath $proxy -PathType Leaf) -and (Hash $proxy) -ne 'ce596412befa68c30b7f88f65beb77d9bdad55e9b96a276a5a9cf690c63f24bb') {
    throw 'Existing proxy differs from the original PursuitAI install. No replacement performed.'
}
if (-not $EnableLoader -and (Test-Path -LiteralPath $proxy -PathType Leaf)) {
    & (Join-Path $PSScriptRoot 'Disable-Alpha.ps1') -GameRoot $game
}
$stage=Join-Path ([IO.Path]::GetTempPath()) ('PursuitAI-repair-'+[guid]::NewGuid().ToString('N'))
$backupRoot=Join-Path $PSScriptRoot ('backups\'+[DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N'))
$plan=New-Object 'System.Collections.Generic.List[object]'
$applied=New-Object 'System.Collections.Generic.List[object]'
$utf8=New-Object Text.UTF8Encoding($false)
try {
    $null=New-Item -ItemType Directory -Path $stage
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    foreach ($zipPath in @($archive,$oldProxyArchive)) {
        $target=if ($zipPath -eq $archive) { Join-Path $stage 'new' } else { Join-Path $stage 'old' }
        $zip=[IO.Compression.ZipFile]::OpenRead($zipPath)
        try { foreach ($entry in $zip.Entries) { $null=Within (Join-Path $target $entry.FullName) $target } }
        finally { $zip.Dispose() }
        [IO.Compression.ZipFile]::ExtractToDirectory($zipPath,$target)
    }
    $plan.Add(@{source=(Join-Path $stage 'new\ue4ss\UE4SS.dll');target=(Join-Path $win 'UE4SS.dll')})
    if ($EnableLoader -and -not (Test-Path -LiteralPath $proxy -PathType Leaf)) {
        $plan.Add(@{source=(Join-Path $stage 'old\dwmapi.dll');target=$proxy})
    }
    $null=New-Item -ItemType Directory -Path $contentMods -Force
    $sourceMod=Join-Path $PSScriptRoot 'PursuitAI'
    foreach ($file in Get-ChildItem -LiteralPath $sourceMod -Recurse -File) {
        $relative=$file.FullName.Substring($sourceMod.Length).TrimStart('\')
        if ($relative -in @('startup_status.txt','runtime_trace.log','diagnostics.txt')) { continue }
        $target=Join-Path $contentMods ('PursuitAI\'+$relative)
        if ($relative -eq 'settings.ini' -and (Test-Path -LiteralPath $target -PathType Leaf)) { continue }
        $plan.Add(@{source=$file.FullName;target=$target})
    }
    $plan.Add(@{source=(Join-Path $stage 'new\ue4ss\Mods\shared\UEHelpers\UEHelpers.lua');target=(Join-Path $contentMods 'shared\UEHelpers\UEHelpers.lua')})
    $plan.Add(@{source=(Join-Path $PSScriptRoot 'shared\ModMenu\ModMenu.lua');target=(Join-Path $contentMods 'shared\ModMenu\ModMenu.lua')})
    $iniPath=Join-Path $win 'UE4SS-settings.ini'
    $ini=if (Test-Path -LiteralPath $iniPath -PathType Leaf) { [IO.File]::ReadAllText($iniPath) } else { [IO.File]::ReadAllText((Join-Path $stage 'new\ue4ss\UE4SS-settings.ini')) }
    $ini=Set-Ini $ini 'Overrides' 'ModsFolderPath' ($contentMods.Replace('\','/'))
    $ini=Set-Ini $ini 'Overrides' 'ControllingModsTxt' ((Join-Path $contentMods 'mods.txt').Replace('\','/'))
    $ini=Set-Ini $ini 'EngineVersionOverride' 'MajorVersion' '4'
    $ini=Set-Ini $ini 'EngineVersionOverride' 'MinorVersion' '27'
    $ini=Set-Ini $ini 'General' 'UseCache' '0'
    $ini=Set-Ini $ini 'General' 'bUseUObjectArrayCache' 'false'
    $ini=Set-Ini $ini 'General' 'bForceGUObjectArrayForIteration' 'true'
    $ini=Set-Ini $ini 'General' 'DefaultExecuteInGameThreadMethod' 'ProcessEvent'
    $ini=Set-Ini $ini 'General' 'SecondsToScanBeforeGivingUp' '30'
    # InitGameState alone reproduces a native crash in the pinned 1.11.7 binary.
    # ProcessEvent supplies game-thread execution without the EngineTick detour.
    $ini=Set-Ini $ini 'Hooks' 'HookInitGameState' '0'
    $ini=Set-Ini $ini 'Hooks' 'HookEngineTick' '0'
    $ini=Set-Ini $ini 'Debug' 'GuiConsoleEnabled' '0'
    $ini=Set-Ini $ini 'Debug' 'ConsoleEnabled' '0'
    $plan.Add(@{text=$ini;target=$iniPath})
    $modsPath=Join-Path $contentMods 'mods.txt'
    $modsText=if (Test-Path -LiteralPath $modsPath -PathType Leaf) { [IO.File]::ReadAllText($modsPath) } else { '' }
    if ($modsText -match '(?m)^\s*PursuitAI\s*:') {
        $modsText=[regex]::Replace($modsText,'(?m)^\s*PursuitAI\s*:[^\r\n]*','PursuitAI : 1')
    } else { $modsText=$modsText.TrimEnd()+"`r`nPursuitAI : 1`r`n" }
    $plan.Add(@{text=$modsText;target=$modsPath})
    $marker=if($EnableLoader){'Alpha 1.0.1: installed for explicit test; startup pending'}else{'Alpha 1.0.1: installed inactive; loader disabled'}
    $plan.Add(@{text=($marker+"`r`n");target=(Join-Path $contentMods 'PursuitAI\startup_status.txt')})
    foreach($asset in Get-PursuitVehiclePlan $PSScriptRoot $VehicleRoot){$plan.Add($asset)}
    foreach ($item in $plan) {
        $scope=if($item.asset){$item.root}else{$game}
        $item.target=Within $item.target $scope
        if ($item.source -and -not (Test-Path -LiteralPath $item.source -PathType Leaf)) { throw "Missing repair source: $($item.source)" }
    }
    $null=New-Item -ItemType Directory -Path $backupRoot -Force
    $oldLog=Join-Path $win 'UE4SS.log'
    if (Test-Path -LiteralPath $oldLog -PathType Leaf) { Copy-Item -LiteralPath $oldLog -Destination (Join-Path $backupRoot 'UE4SS-before-repair.log') }
    foreach ($item in $plan) {
        $relative=if($item.asset){$item.relative}else{$item.target.Substring($game.TrimEnd('\').Length).TrimStart('\')}
        $before=$null
        if (Test-Path -LiteralPath $item.target -PathType Leaf) {
            $before=Within (Join-Path $backupRoot $relative) $backupRoot
            $null=New-Item -ItemType Directory -Path (Split-Path -Parent $before) -Force
            Copy-Item -LiteralPath $item.target -Destination $before
        }
        $record=@{path=$item.target;backup=$before;asset=$item.asset;root=$item.root}
        $applied.Add($record)
        $null=New-Item -ItemType Directory -Path (Split-Path -Parent $item.target) -Force
        if ($item.source) { Copy-Item -LiteralPath $item.source -Destination $item.target -Force }
        else { [IO.File]::WriteAllText($item.target,$item.text,$utf8) }
        $record.after_sha256=Hash $item.target
        if($item.source -and $record.after_sha256 -ne (Hash $item.source)){throw 'Installed file checksum mismatch.'}
    }
    $manifest=@{version='Alpha 1.0.1';game_root=$game;mods_root=$contentMods;backup_root=$backupRoot;
        loader_asset='UE4SS_v3.0.1-1176-g1ba38db4.zip';changed_files=$applied.ToArray();live_start_verified=$false}
    [IO.File]::WriteAllText((Join-Path $backupRoot 'repair-manifest.json'),($manifest | ConvertTo-Json -Depth 7),$utf8)
    Write-Host 'PursuitAI Alpha 1.0.1 files installed. MADE BY MR.HOGE. English default; reinforcements opt-in. Read README_EN.md. See README_RU.md.'
    if (-not $EnableLoader) { Write-Host 'Loader was not re-enabled. Use an explicit test installation only after reviewing validation.' }
    Write-Host ('Mod folder: '+(Join-Path $contentMods 'PursuitAI'))
    Write-Host ('Backup: '+$backupRoot)
} catch {
    for ($i=$applied.Count-1;$i -ge 0;$i--) {
        $entry=$applied[$i]
        $scope=if($entry.asset){$entry.root}else{$game}
        $target=Within $entry.path $scope
        if ($entry.backup) { Copy-Item -LiteralPath $entry.backup -Destination $target -Force }
        elseif (Test-Path -LiteralPath $target -PathType Leaf) { Remove-Item -LiteralPath $target }
    }
    throw
} finally {
    if (Test-Path -LiteralPath $stage) {
        $prefix=[IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\')+'\PursuitAI-repair-'
        if (-not ([IO.Path]::GetFullPath($stage)).StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)) { throw 'Staging cleanup path check failed.' }
        Remove-Item -LiteralPath $stage -Recurse -Force
    }
}
