param([string]$GameRoot = '')
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Find-Game.ps1')
$GameRoot = Resolve-PursuitGameRoot -GameRoot $GameRoot
if (Get-Process -Name 'BrickRigsSteam-Win64-Shipping','BrickRigs' -ErrorAction SilentlyContinue) { throw 'Close Brick Rigs before disabling the loader.' }
$game=[IO.Path]::GetFullPath($GameRoot).TrimEnd('\')
$proxy=[IO.Path]::GetFullPath((Join-Path $game 'BrickRigs\Binaries\Win64\dwmapi.dll'))
if (-not $proxy.StartsWith(($game+'\'),[StringComparison]::OrdinalIgnoreCase)) { throw 'Invalid game path.' }
if (-not (Test-Path -LiteralPath $proxy -PathType Leaf)) { Write-Host 'The PursuitAI loader proxy is already disabled.'; return }
$hash=(Get-FileHash -LiteralPath $proxy -Algorithm SHA256).Hash.ToLowerInvariant()
if ($hash -ne 'ce596412befa68c30b7f88f65beb77d9bdad55e9b96a276a5a9cf690c63f24bb') { throw 'Unknown dwmapi.dll: not moving a file belonging to another installation.' }
$backup=Join-Path $PSScriptRoot ('backups\disabled-'+[DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss')+'-'+[guid]::NewGuid().ToString('N'))
$null=New-Item -ItemType Directory -Path $backup
Move-Item -LiteralPath $proxy -Destination (Join-Path $backup 'dwmapi.dll.disabled')
Write-Host ('UE4SS startup disabled. Saved proxy: '+$backup)
Write-Host 'Mod settings, vehicle archive, game executable and saved games were retained.'
