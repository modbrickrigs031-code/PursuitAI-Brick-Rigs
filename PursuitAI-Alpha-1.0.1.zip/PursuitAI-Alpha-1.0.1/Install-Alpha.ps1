param([string]$GameRoot = '',[switch]$EnableLoader,[switch]$CheckGamePath,[string]$VehicleRoot=(Join-Path $env:LOCALAPPDATA 'BrickRigs\SavedRemastered\Vehicles'))
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Find-Game.ps1')
$GameRoot = Resolve-PursuitGameRoot -GameRoot $GameRoot
if ($CheckGamePath) { Write-Output $GameRoot; return }
& (Join-Path $PSScriptRoot 'Repair-Alpha.ps1') -GameRoot $GameRoot -EnableLoader:$EnableLoader -VehicleRoot $VehicleRoot
