param([string]$GameRoot = '')
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Find-Game.ps1')
$GameRoot = Resolve-PursuitGameRoot -GameRoot $GameRoot
& (Join-Path $PSScriptRoot 'Disable-Alpha.ps1') -GameRoot $GameRoot
Write-Host 'All files retained for recovery; automatic loading disabled.'
