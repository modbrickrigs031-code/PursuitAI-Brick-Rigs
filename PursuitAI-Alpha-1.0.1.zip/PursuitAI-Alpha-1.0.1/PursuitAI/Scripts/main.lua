-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
-- A persistent marker distinguishes loader failure from Lua/module initialization failure.
local source=debug.getinfo(1,"S").source
local scripts=source:sub(1,1)=="@" and source:sub(2):match("^(.*)[/\\]main%.lua$") or nil
if not scripts then print("[PursuitAI] Cannot determine main.lua path\n");return end
local root=scripts.."/.."
local function status(message)
    local f=io.open(root.."/startup_status.txt","w")
    if f then f:write(message.."\n");f:close() end
    print("[PursuitAI] "..message.."\n")
end
status("Alpha 1.0.1: Lua entry point reached")
package.path=scripts.."/?.lua;"..package.path
local retained={}
package.loaded["pursuit.bootstrap"]=retained
retained.start=function()
    local ok,err=xpcall(function()
        assert(type(LoopInGameThreadWithDelay)=="function","Game-thread timers are required")
        local run=require("pursuit.app")
        retained.app=run(scripts,root)
        assert(retained.app,"PursuitAI initialization did not return an application")
        status("Alpha 1.0.1: game-thread initialization complete; F8 menu; compatibility checked on action")
    end,debug.traceback)
    if not ok then status("Alpha 1.0.1: SCRIPT INITIALIZATION FAILED\n"..tostring(err)) end
end
ExecuteInGameThread(retained.start)
