-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
return {
 ["415"]={local_id="PursuitAI_415",fnv="6e6b7670a9000a69",bytes=52584},
 ["416"]={local_id="PursuitAI_416",fnv="7bbc6b4e4f9a30df",bytes=41441},
 ["419"]={local_id="PursuitAI_419",fnv="2b4d6db50097f02c",bytes=70272},
 ["524"]={local_id="PursuitAI_524",fnv="7485b59f25614669",bytes=50696},
 ["550"]={local_id="PursuitAI_550",fnv="f769b7229d9bed94",bytes=47958},
 ["551"]={local_id="PursuitAI_551",fnv="bd25ba39f8879c3c",bytes=65515},
 ["560"]={local_id="PursuitAI_560",fnv="f7e8919a98850467",bytes=49040},
 ["564"]={local_id="PursuitAI_564",fnv="a3072988343a90ac",bytes=56722},
 ["569"]={local_id="PursuitAI_569",fnv="fcad9077a43d308c",bytes=61053},
 ["586"]={local_id="PursuitAI_586",fnv="c1a1630c1ab5b248",bytes=67442},
 ["642"]={local_id="PursuitAI_642",fnv="003481fc1e1113f0",bytes=49917},
 ["643"]={local_id="PursuitAI_643",fnv="591c972e8587ad22",bytes=84748},
 ["644"]={local_id="PursuitAI_644",fnv="6c5b8fc21040ccc7",bytes=90064},
 ["650"]={local_id="PursuitAI_650",fnv="814e3774ebf3ae8e",bytes=60408},
 ["663"]={local_id="PursuitAI_663",fnv="f2bf0d074960fc5d",bytes=66816},
}
