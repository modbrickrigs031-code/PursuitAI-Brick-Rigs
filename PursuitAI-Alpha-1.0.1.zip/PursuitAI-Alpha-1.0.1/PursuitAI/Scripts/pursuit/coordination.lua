-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local M={}
function M.assign(app,cars,target,now)
    if target.speed_mps*3.6>35 then app.ram_owner=nil;return end
    if target.speed_mps*3.6>30 then return end
    local owner
    for _,car in ipairs(cars) do if car.key==app.ram_owner then owner=car end end
    local tactic=owner and app.tactics[owner.key]
    if owner then
        local distance=math.sqrt((owner.x-target.x)^2+(owner.y-target.y)^2)
        if tactic and app.owner_phase~=tactic.phase then app.owner_best=distance;app.owner_progress=now end
        if not app.owner_best or distance<app.owner_best-1.5 then app.owner_progress=now;app.owner_best=distance end
        -- Backoff/settle are purposeful, but a full lease still bounds their duration.
        if tactic and (tactic.phase=="backoff" or tactic.phase=="settle" or tactic.phase=="align") then app.owner_progress=now end
        app.owner_phase=tactic and tactic.phase
    end
    local committed=owner and owner.yaw~=nil and now-(app.owner_since or now)<35 and math.sqrt((owner.x-target.x)^2+(owner.y-target.y)^2)<12 and
        (owner.speed_mps or 0)>1 and math.abs((math.atan(target.y-owner.y,target.x-owner.x)-owner.yaw+math.pi)%(2*math.pi)-math.pi)<.45 and tactic and tactic.phase~='backoff' and tactic.phase~='settle' and tactic.phase~='align'
    local rotate=owner and not committed and #cars>1 and ((tactic and tactic.attack_completed) or
        now-(app.owner_progress or now)>6 or now-(app.owner_since or now)>35)
    if not owner or rotate then
        local previous=rotate and owner.key
        local best,key=math.huge,nil
        for _,car in ipairs(cars) do
            local d=(car.x-target.x)^2+(car.y-target.y)^2
            if car.key~=previous and d<best then best=d;key=car.key end
        end
        app.ram_owner=key;app.owner_since=now;app.owner_progress=now;app.owner_phase=nil;app.owner_best=nil
        if key and app.tactics[key] then app.tactics[key].attack_completed=nil end
    end
end
return M

