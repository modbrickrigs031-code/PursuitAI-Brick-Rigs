-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local L=require('pursuit.i18n').text
local Fleet=require("pursuit.fleet")
local Settings=require("pursuit.settings")
local M={}

function M.attach(app,root)
    local ok,menu=pcall(require,"ModMenu.ModMenu")
    if not ok then app:message(L("Меню недоступно: F7 — отметить, F9 — начать, F10 — остановить")) return nil end
    menu.Init({title="MADE BY MR.HOGE | PursuitAI Alpha 1.0.1",instanceId="PursuitAI",key=Key.F8,keyHint="F8",
        dock="left",widthFrac=0.42,theme="dark",tabs={L("Обучение"),L("Погоня"),L("Автопарк"),L("Настройки")},ignoreLook=true,
        inputBackend="engine",keyName="F8",getPlayerController=function() return app.adapter:controller() end})
    local function probability_labels()
        local rows=Fleet.probabilities(app.cfg.fleet,app.available_models)
        for _,row in ipairs(rows) do
            menu.SetLabel("Fleet_"..row.id,"chance",string.format(L("Шанс в доступном пуле: %.2f%%"),row.probability*100))
        end
    end
    local function save()
        local saved,err=Settings.save(root.."/settings.ini",app.cfg)
        app:message(saved and L("Настройки сохранены.") or L("Сохранение не удалось: ")..tostring(err))
    end
    menu.Register({id="Guide",title=L("Обучение"),tab=L("Обучение"),items={
{type="label",label="MADE BY MR.HOGE"},
{type="label",label=L("1. Установи мод при закрытой игре. F8 открывает это меню.")},
{type="label",label=L("2. Хост: создай машину копа, сядь в неё, нажми F7 и выйди. Повтори для других копов.")},
{type="label",label=L("3. Сядь в машину гонщика. Выбери «Я» или обнови список игроков и выбери друга, который сидит в машине.")},
{type="label",label=L("4. F9 — начать; F10 — остановить; F11 — сбросить отметки. Перед новой разметкой останови погоню.")},
{type="label",label=L("Подкрепления выключены по умолчанию. Включи их в настройках перед новой погоней; установи запас и веса в автопарке.")},
}})
    menu.Register({id="Pursuit",title=L("Погоня"),tab=L("Погоня"),items={
        {type="label",id="status",label=L("Сядь в машину копа и отметь её.")},
        {type="label",id="count",label=L("Отмечено машин: 0")},
        {type='button',id='refresh_players',label=L('Обновить список игроков'),onClick=function() app:dispatch(function() app:refresh_players() end) end},
        {type='dropdown',id='target',label=L('Игрок, которого атакуют копы'),searchable=true,
            options={{label=L('Я — моя текущая машина'),value='__self'}},default='__self',
            onChange=function(value) app:dispatch(function() app:select_target_player(value) end) end},
        {type="button",id="register",label=L("1. Отметить машину копа  ·  F7"),onClick=function() app:dispatch(function() app:register_current() end) end},
        {type="label",label=L("На сервере: хост создаёт и отмечает копов, выходит из них и выбирает игрока-цель. Цель должна сидеть в машине.")},
        {type="button",id="start",label=L("2. Начать погоню  ·  F9"),onClick=function() app:dispatch(function() app:start() end) end},
        {type="button",id="stop",label=L("Остановить  ·  F10"),onClick=function() app:dispatch(function() app:stop();app:message(L("Погоня остановлена.")) end) end},
        {type="label",label=L("Выбери «Я» для погони на себя или игрока из списка. Копами и подкреплениями управляет хост. F8 — закрыть меню.")}
    }})
    menu.Register({id="Options",title=L("Управление"),tab=L("Настройки"),items={
        {type='dropdown',id='language',label=L('Язык / Language (сразу)'),options={{label='English',value='en'},{label='Русский',value='ru'}},default=app.cfg.language,
            onChange=function(value) if value=='en' or value=='ru' then app.cfg.language=value;save();app.pending_language=value end end},
        {type='checkbox',id='reinforcements_enabled',label=L('Включить подкрепления в следующей погоне'),default=app.cfg.session.reinforcements_enabled,
            onChange=function(value) app.cfg.session.reinforcements_enabled=value;save() end},
        {type="button",id="reset",label=L("Сбросить отметки машин"),onClick=function() app:dispatch(function() app:reset() end) end},
        {type="checkbox",id="sirens",label=L("Включать сирены копов"),default=app.cfg.drive.sirens_enabled,
            onChange=function(on) app.cfg.drive.sirens_enabled=on end},
        {type="checkbox",id="beacons",label=L("Включать световые мигалки копов (X)"),default=app.cfg.drive.beacons_enabled,
            onChange=function(on) app.cfg.drive.beacons_enabled=on end},
        {type="checkbox",id="stability",label=L("Коррекция руля и газа при заносе"),default=app.cfg.drive.stability_enabled,
            onChange=function(on) app.cfg.drive.stability_enabled=on end},
        {type="number",id="aggression",label=L("Агрессия (0,5–2): частота повторных атак"),min=.5,max=2,step=.05,default=app.cfg.drive.aggression,
            onChange=function(v) if Fleet.finite(v) and v>=.5 and v<=2 then app.cfg.drive.aggression=v end end},
        {type="checkbox",id="ram",label=L("Повторные тараны при скорости цели до 30 км/ч"),default=app.cfg.drive.ram_enabled,
            onChange=function(on) app.cfg.drive.ram_enabled=on end},
        {type="number",id="retreat",label=L("Дистанция отхода перед тараном, м"),min=5,max=35,default=app.cfg.drive.ram_retreat_m,
            onChange=function(value) if Fleet.finite(value) and value>=5 and value<=35 then app.cfg.drive.ram_retreat_m=value end end},
        {type="number",id="cruise",label=L("Скорость преследования на свободном пути, км/ч"),min=30,max=500,default=app.cfg.drive.cruise_kmh,
            onChange=function(value) if Fleet.finite(value) and value>=30 and value<=500 then app.cfg.drive.cruise_kmh=value end end},
        {type="number",id="ram_speed",label=L("Скорость разгона для тарана, км/ч"),min=30,max=70,default=app.cfg.drive.ram_speed_kmh,
            onChange=function(value) if Fleet.finite(value) and value>=30 and value<=70 then app.cfg.drive.ram_speed_kmh=value end end},
        {type="number",id="cleanup",label=L("Убрать выведенную из строя машину через, с"),min=5,max=600,
            default=app.cfg.session.cleanup_delay_s,onChange=function(value)
                if Fleet.finite(value) and value>=5 and value<=600 then app.cfg.session.cleanup_delay_s=value end
            end},
        {type="number",id="reserve",label=L("Запас подкрепления на новую погоню"),min=0,max=50,step=1,default=app.cfg.session.reserve,
            onChange=function(v) if Fleet.finite(v) and v>=0 and v<=50 and v%1==0 then app.cfg.session.reserve=v end end},
        {type="number",id="reinforce_delay",label=L("Пауза между попытками подкрепления, с"),min=3,max=60,default=app.cfg.session.reinforcement_delay_s,
            onChange=function(v) if Fleet.finite(v) and v>=3 and v<=60 then app.cfg.session.reinforcement_delay_s=v end end},
        {type="checkbox",id="immobilized",label=L("Выводить из погони перевёрнутые и безнадёжно застрявшие авто"),default=app.cfg.session.immobilized_cleanup,
            onChange=function(v) app.cfg.session.immobilized_cleanup=v end},
        {type="number",id="overturned",label=L("Признать перевёрнутого копа выбывшим через, с"),min=3,max=30,default=app.cfg.session.overturned_after_s,
            onChange=function(v) if Fleet.finite(v) and v>=3 and v<=30 then app.cfg.session.overturned_after_s=v end end},
        {type="number",id="trapped",label=L("Застревание после нескольких попыток выезда, с"),min=20,max=120,default=app.cfg.session.stuck_after_s,
            onChange=function(v) if Fleet.finite(v) and v>=20 and v<=120 then app.cfg.session.stuck_after_s=v end end},
        {type="button",id="save",label=L("Сохранить настройки"),onClick=save},
        {type="button",id="probe",label=L("Проверить совместимость"),onClick=function() app:dispatch(function() app:probe() end) end},
        {type="label",label=L("Копы проверяют путь перед собой и сзади. Это местный объезд препятствий; держат точку объезда стены. Глобального маршрута по дорогам пока нет.")}
    }})
    menu.Register({id="FleetInfo",title=L("Состав подкрепления"),tab=L("Автопарк"),items={
        {type="label",label=L("Подкрепление появляется вне экрана на свободном месте, после уборки выбывшей машины. Запас конечный.")},
        {type="label",label=L("Шанс = вес машины / сумма включённых весов. Вес 0 исключает машину. При общей сумме 0 выбор отключён.")},
        {type="button",id="save",label=L("Сохранить автопарк"),onClick=save}
    }})
    for _,model in ipairs(app.cfg.fleet) do
        local row=model
        local id="Fleet_"..row.id
        menu.Register({id=id,title=row.id.." · "..row.name,tab=L("Автопарк"),collapsible=true,collapsed=true,items={
            {type="checkbox",id="enabled",label=L("Включить в подкрепление"),default=row.enabled,
                onChange=function(on) row.enabled=on;probability_labels() end},
            {type="number",id="weight",label=L("Вес появления"),min=0,max=1000000,default=row.weight,
                onChange=function(value)
                    if Fleet.finite(value) and value>=0 then row.weight=value;probability_labels() end
                end},
            {type="label",id="chance",label=L("Вероятность рассчитывается…")},
        }})
    end
    if not app.locale_open_hook then menu.OnOpen(function() if app.update_probability_labels then app.update_probability_labels() end end);app.locale_open_hook=true end
    app.update_probability_labels=probability_labels
    probability_labels()
    return menu
end

return M
