-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local M={}
local function clamp(v,a,b) return math.max(a,math.min(b,v)) end
function M.command(s,car,cmd,cfg,now)
    local dt=s.last_at and now-s.last_at or 0
    local rate=dt>.02 and dt<.5 and ((car.yaw-(s.last_yaw or car.yaw)+math.pi)%(2*math.pi)-math.pi)/dt or 0
    s.last_yaw=car.yaw;s.last_at=now
    if cfg.stability_enabled==false or cmd.ram_committed or cmd.traffic_wait or cmd.traffic_escape or cmd.brake>=.65 or
        (cmd.direction or (cmd.throttle<0 and -1 or 1))<0 or (car.up_z or 1)<.65 or car.speed_mps<6 then return cmd end
    local forward=(car.vx or 0)*math.cos(car.yaw)+(car.vy or 0)*math.sin(car.yaw)
    local lateral=-(car.vx or 0)*math.sin(car.yaw)+(car.vy or 0)*math.cos(car.yaw)
    local slip=math.atan(lateral,math.max(1,math.abs(forward)))
    if math.abs(slip)<.18 then return cmd end
    local weight=clamp((math.abs(slip)-.12)/.35,.2,1)
    local counter=clamp(slip*1.8-rate*.2,-1,1)
    cmd.steering=clamp(cmd.steering*(1-weight)+counter*weight,-1,1)
    cmd.throttle=math.min(cmd.throttle,math.abs(slip)>.45 and .1 or .35)
    -- Leave service/emergency braking to obstacle checks after steering correction.
    cmd.reason='skid_recover';cmd.slip_rad=slip
    return cmd
end
return M
