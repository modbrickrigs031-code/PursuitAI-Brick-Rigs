-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local M = {}
local function clamp(x, lo, hi) return math.max(lo, math.min(hi, x)) end
local function length(x, y) return math.sqrt(x*x+y*y) end

-- All core distances are metres and all core speeds are metres/second.
-- terrain is measured input from an adapter, never inferred from a preview.
function M.command(car, target, cfg, terrain,state)
    local dx, dy = target.x-car.x, target.y-car.y
    local distance = length(dx, dy)
    local lead = clamp(distance/35, 0, cfg.max_lead_s)
    if target.lead_limit_s then lead=math.min(lead,math.max(0,target.lead_limit_s)) end
    dx = dx + (target.vx or 0)*lead; dy = dy + (target.vy or 0)*lead
    local heading = math.atan(dy, dx) - car.yaw
    heading = (heading + math.pi) % (2*math.pi) - math.pi
    local steer = clamp(heading/cfg.steer_full_angle_rad, -1, 1)
    local speed_limit = cfg.cruise_kmh/3.6
    speed_limit = math.min(speed_limit, cfg.corner_kmh/3.6 + (1-math.abs(steer))*speed_limit)
    local reason = "pursuit"
    if terrain and terrain.valid and terrain.obstacle_distance_m and terrain.obstacle_distance_m<cfg.obstacle_stop_m then
        return {steering=steer,throttle=0,brake=1,desired_speed_mps=0,reason="obstacle"}
    end
    -- No stuck timeout counts as vehicle destruction; a stopped cop may be waiting.
    local turning=math.abs(heading)>cfg.reverse_angle_rad and (car.speed_mps or 0)<1.5
    if state then
        if turning then state.drive_reverse=true end
        if math.abs(heading)<1.1 then state.drive_reverse=nil end
        turning=state.drive_reverse==true
    end
    if turning then
        return {steering=-steer,throttle=(car.speed_mps or 0)<4 and -math.max(.4,cfg.reverse_throttle) or 0,
                brake=(car.speed_mps or 0)>4.5 and .5 or 0,direction=-1,
                desired_speed_mps=4,reason="turn_around"}
    end
    local error = speed_limit-(car.speed_mps or 0)
    return {steering=steer, throttle=clamp(error/cfg.throttle_gain_mps,0,1),
            brake=clamp(-error/cfg.brake_gain_mps,0,1), desired_speed_mps=speed_limit, reason=reason}
end

return M
