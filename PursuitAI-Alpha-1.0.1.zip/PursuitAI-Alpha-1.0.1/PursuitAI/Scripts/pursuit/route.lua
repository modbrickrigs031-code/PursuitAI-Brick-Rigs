-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local Drive=require("pursuit.drive")
local Geometry=require("pursuit.geometry")
local M={}
local function follow_detour(s,car,cmd,cfg)
    local tuning={};for k,v in pairs(cfg) do tuning[k]=v end
    tuning.cruise_kmh=math.min(35,cfg.cruise_kmh)
    local result=Drive.command(car,s.detour,tuning,nil,s)
    result.reason="wall_detour";result.allow_target_contact=cmd.allow_target_contact
    return result
end
-- Keep a lateral waypoint until it is reached. Otherwise the pursuit steering
-- immediately pulls back into the same wall on the following frame.
function M.command(s,car,cmd,sensors,cfg,now,target)
    if not sensors or sensors.valid==false then return cmd end -- Avoidance stops safely.
    -- Retreat, settling and alignment have their own bounded trajectory.
    -- An old forward detour must not turn a requested reverse into forward drive.
    if cmd.reason=="ram_backoff" or cmd.reason=="ram_settle" or cmd.reason=="ram_align" or cmd.reason=="ram_backoff_no_motion" then
        s.detour=nil
        return cmd
    end
    -- Abandon a support/old-obstacle waypoint when the direct attack is now clear.
    -- Real walls still pass through the normal detour and avoidance checks.
    local contact_range=target and math.max(0,Geometry.gap(car,target))+2 or math.huge
    if (cmd.ramming or cmd.allow_target_contact) and sensors.front>=contact_range and (sensors.planned or math.huge)>=contact_range then
        s.detour=nil
        -- Do not immediately create the waypoint we have just discarded. At
        -- speed the warning distance can extend beyond the target/contact gap.
        return cmd
    end
    if s.detour and target and s.detour.target_x and (target.x-s.detour.target_x)^2+(target.y-s.detour.target_y)^2>64 then s.detour=nil end
    if s.detour then
        local p=s.detour
        local d=(p.x-car.x)^2+(p.y-car.y)^2
        if d<4 or now>p.expires then s.detour=nil;s.detour_after=now+1
        else
            return follow_detour(s,car,cmd,cfg)
        end
    end
    local speed=car.speed_mps or 0
    local warn=math.max(10,2+speed*.5+speed*speed/10)
    if not s.recovery and (cmd.direction or 1)>0 and sensors.front<warn and now>=(s.detour_after or 0) then
        local left=math.min(sensors.left,sensors.side_left or sensors.left)
        local right=math.min(sensors.right,sensors.side_right or sensors.right)
        local sign,clear=Geometry.clear_side(left,right,cmd.steering)
        if clear>5 then
            local forward=math.max(0,math.min(5,sensors.front-4))
            local lateral=math.min(12,clear-2)
            s.detour={x=car.x+math.cos(car.yaw)*forward-math.sin(car.yaw)*sign*lateral,
                y=car.y+math.sin(car.yaw)*forward+math.cos(car.yaw)*sign*lateral,
                expires=now+6,vx=0,vy=0,target_x=target and target.x,target_y=target and target.y}
            -- Evaluate a new waypoint once; route selection never calls itself.
            return follow_detour(s,car,cmd,cfg)
        end
    end
    return cmd
end
return M
