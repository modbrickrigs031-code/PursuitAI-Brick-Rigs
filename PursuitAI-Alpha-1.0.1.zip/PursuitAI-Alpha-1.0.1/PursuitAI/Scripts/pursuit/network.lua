-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local L=require('pursuit.i18n').text
-- Host-owned police only. Player identities are session objects, never nicknames.
local M={}
local function name(a,obj) return a:string(obj:GetFullName()) end
function M.is_host(a)
    if not a.multiplayer then return true end
    local ok,yes=pcall(function() return a:controller():HasAuthority() end)
    return ok and yes==true
end
function M.same_world(a,pc)
    local ok,yes=pcall(function()
        return name(a,pc:GetWorld())==name(a,a:controller():GetWorld())
    end)
    return ok and yes
end
function M.players(a)
    assert(M.is_host(a),L('Список целей доступен у хоста сервера'))
    local rows,seen={},{}
    for _,pc in ipairs(FindAllOf('BrickPlayerController') or {}) do
        if a.valid(pc) and M.same_world(a,pc) then
            local ok,row=pcall(function()
                local ps=pc.PlayerState
                if not a.valid(ps) then return end
                local key=name(a,ps)
                local label=a:string(ps:GetPlayerName()):gsub('[\r\n]',' ')
                if label=='' then label=L('Игрок') end
                return {key=key,label=label,controller=pc,state=ps}
            end)
            if ok and row and not seen[row.key] then seen[row.key]=true;rows[#rows+1]=row end
        end
    end
    table.sort(rows,function(x,y) if x.label==y.label then return x.key<y.key end;return x.label<y.label end)
    return rows
end
function M.connected(a,row)
    if not row or not a.valid(row.controller) or not a.valid(row.state) or not M.same_world(a,row.controller) then return false end
    local ok,same=pcall(function() return name(a,row.controller.PlayerState)==row.key end)
    return ok and same
end
function M.assert_vehicle(a,vehicle)
    if not a.multiplayer then return end
    assert(M.is_host(a),L('Копами может управлять только хост'))
    assert(vehicle:HasAuthority(),L('У хоста нет полномочий над этой машиной'))
    assert(vehicle.bReplicates==true,L('Машина не реплицируется: выбери созданную хостом машину'))
    local owner=vehicle.SpawningPlayerState
    if a.valid(owner) then
        local host=a:controller().PlayerState
        assert(a.valid(host) and name(a,owner)==name(a,host),L('Машину копа должен создать хост, а не удалённый игрок'))
    end
end
function M.prepare_spawn(a,actor)
    if not a.multiplayer then return end
    assert(M.is_host(a) and actor:HasAuthority(),L('Подкрепление создаёт только хост'))
    local pc=a:controller();local ps=pc.PlayerState
    assert(a.valid(ps),L('PlayerState хоста недоступен'))
    local previous=actor.SpawningPlayerState
    assert(not a.valid(previous) or name(a,previous)==name(a,ps),L('Владение новым подкреплением изменилось'))
    actor:SetOwner(pc)
    actor.SpawningPlayerState=ps
    actor:SetReplicates(true)
    assert(actor.bReplicates==true and name(a,actor.SpawningPlayerState)==name(a,ps),L('Не удалось назначить сетевое владение подкреплением'))
end
return M
