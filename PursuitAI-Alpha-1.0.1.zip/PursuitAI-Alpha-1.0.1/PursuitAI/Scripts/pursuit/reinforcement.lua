-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local L=require('pursuit.i18n').text
local M={}
function M.tick(app,target,now)
    local s,spawn=app.session,app.spawner
    if spawn.pending then
        local token=spawn.pending.request.token
        if s.state~="running" or not s.pending or s.pending.token~=token then
            local pending=spawn.pending
            if s.state=='running' and now>=pending.request.expires and pending.departure and not pending.departed then
                app.failed_launches=app.failed_launches or {};local id=pending.request.model_id
                app.failed_launches[id]=(app.failed_launches[id] or 0)+1
                app:trace('reinforcement:no_departure:'..id)
                if app.failed_launches[id]>=2 then
                    app.available_models[id]=false
                    app:message(L('Модель ')..id..L(' дважды не смогла тронуться и исключена из текущей погони. Веса сохранены.'))
                end
            end
            spawn:discard();return
        end
        local ok,item,reason=pcall(function() return spawn:poll(target,now) end)
        if not ok then reason=tostring(item);item=nil end
        if item then
            local accepted=s:spawn_ack(token,item.key,true,now)
            if accepted then
                app.registration[item.key]=item;spawn:accept();app:refresh_count()
                app:trace("reinforcement:confirmed:"..item.model_id..":"..item.key)
                app:message(L("Подкрепление вступило в погоню. Осталось в запасе: ")..s.reserve)
            else spawn:discard() end
            app.next_reinforcement=now+app.cfg.session.reinforcement_delay_s
        elseif reason then
            s:spawn_ack(token,nil,false,now);spawn:discard()
            app:trace("reinforcement:retry:"..reason)
            app.next_reinforcement=now+app.cfg.session.reinforcement_delay_s
        end
        return
    end
    if s.state~="running" or s.reserve<=0 or s.replacement_slots<=0 or now<(app.next_reinforcement or 0) then return end
    local physical=0
    for _,u in pairs(s.units) do if u.state~="removed" then physical=physical+1 end end
    if physical>=app.initial_count then return end -- wait for delayed wreck cleanup
    app.next_reinforcement=now+app.cfg.session.reinforcement_delay_s
    local candidate_ok,candidate=pcall(function() return spawn:candidate(target,now) end)
    if not candidate_ok then app:trace('reinforcement:waiting_for_view_or_ground:'..tostring(candidate));return end
    if not candidate then app:trace("reinforcement:waiting_for_safe_hidden_position");return end
    local request,reason=s:request_spawn(now,candidate,target,"racer",app.available_models)
    if not request then
        if reason=="empty_fleet" then s.reserve=0;app:message(L("Подкрепление отключено: нет доступных машин с положительным весом.")) end
        return
    end
    local ok,err=pcall(function() spawn:begin(request,app.target_actor) end)
    if not ok then s:spawn_ack(request.token,nil,false,now);spawn:discard();app:trace("reinforcement:failed:"..tostring(err))
    else app:trace("reinforcement:constructing:"..request.model_id) end
end
return M
