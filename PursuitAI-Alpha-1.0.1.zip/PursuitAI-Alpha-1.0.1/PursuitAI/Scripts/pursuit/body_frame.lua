-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local M={}
local function dot(a,b) return a.X*b.X+a.Y*b.Y+a.Z*b.Z end
local function basis(r)
    local p,y,r=math.rad(r.Pitch),math.rad(r.Yaw),math.rad(r.Roll)
    local cp,sp,cy,sy,cr,sr=math.cos(p),math.sin(p),math.cos(y),math.sin(y),math.cos(r),math.sin(r)
    return {{X=cp*cy,Y=cp*sy,Z=sp},{X=sr*sp*cy-cr*sy,Y=sr*sp*sy+cr*cy,Z=-sr*cp},
        {X=-cr*sp*cy-sr*sy,Y=-cr*sp*sy+sr*cy,Z=cr*cp}}
end
local function local_vector(v,b) return {X=dot(v,b[1]),Y=dot(v,b[2]),Z=dot(v,b[3])} end
local function world_vector(v,b)
    return {X=b[1].X*v.X+b[2].X*v.Y+b[3].X*v.Z,Y=b[1].Y*v.X+b[2].Y*v.Y+b[3].Y*v.Z,Z=b[1].Z*v.X+b[2].Z*v.Y+b[3].Z*v.Z}
end
function M.sample(cache,key,seat_id,seat_position,seat_rotation,velocity,actor_rotation,origin,extent)
    local sb=basis(seat_rotation);local saved=cache[key]
    if not saved or saved.seat~=seat_id then
        local ab=basis(actor_rotation);local dx={X=origin.X-seat_position.X,Y=origin.Y-seat_position.Y,Z=origin.Z-seat_position.Z}
        local ca,sa=math.abs(ab[1].X),math.abs(ab[1].Y);local determinant=ca*ca-sa*sa
        local length,width=2.5,1.15
        local sensible=dot(dx,dx)<1000^2 and extent.X<1200 and extent.Y<1200 and extent.Z<500
        if sensible and math.abs(determinant)>.3 and math.abs(actor_rotation.Pitch)<20 and math.abs(actor_rotation.Roll)<20 then
            local l,w=(extent.X*ca-extent.Y*sa)/determinant/100,(extent.Y*ca-extent.X*sa)/determinant/100
            if l>.3 and l<10 and w>.3 and w<5 then length,width=l,w end
        end
        saved={seat=seat_id,axes={},offset=sensible and local_vector(dx,sb) or {X=0,Y=0,Z=0},
            length=length,width=width,height=sensible and math.min(200,extent.Z) or 100}
        for i=1,3 do saved.axes[i]=local_vector(ab[i],sb) end
        cache[key]=saved
    end
    local f,r,u=world_vector(saved.axes[1],sb),world_vector(saved.axes[2],sb),world_vector(saved.axes[3],sb)
    local off=world_vector(saved.offset,sb)
    local center={X=seat_position.X+off.X,Y=seat_position.Y+off.Y,Z=seat_position.Z+off.Z}
    return {key=key,x=center.X/100,y=center.Y/100,z=center.Z/100,center=center,
        low_center={X=center.X,Y=center.Y,Z=center.Z-math.max(0,saved.height-40)},
        half_length_m=saved.length,half_width_m=saved.width,radius_m=saved.length,width_m=saved.width*2,
        forward=f,right=r,up_z=u.Z,yaw=math.atan(f.Y,f.X),
        rotation={Pitch=math.deg(math.atan(f.Z,math.sqrt(f.X*f.X+f.Y*f.Y))),Yaw=math.deg(math.atan(f.Y,f.X)),Roll=math.deg(math.atan(-r.Z,u.Z))},
        extent={X=saved.length*100,Y=saved.width*100,Z=saved.height},
        vx=velocity.X/100,vy=velocity.Y/100,vz=velocity.Z/100,forward_mps=dot(velocity,f)/100,
        speed_mps=math.sqrt(dot(velocity,velocity))/100}
end
return M
