-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local M = {}

function M.finite(x)
    return type(x) == "number" and x == x and x > -math.huge and x < math.huge
end

function M.probabilities(fleet, available)
    local rows, seen, scale = {}, {}, 0
    for _, model in ipairs(fleet) do
        assert(type(model.id) == "string" and model.id ~= "" and not seen[model.id], "Duplicate/invalid model id")
        assert(type(model.enabled) == "boolean", "Invalid enabled flag")
        assert(M.finite(model.weight) and model.weight >= 0, "Weight must be finite and nonnegative")
        seen[model.id] = true
        local eligible = model.enabled and model.weight > 0 and (available == nil or available[model.id] == true)
        rows[#rows + 1] = {id=model.id, weight=eligible and model.weight or 0, probability=0}
        if eligible then scale = math.max(scale, model.weight) end
    end
    if scale == 0 then return rows, false end
    local sum = 0
    for _, row in ipairs(rows) do row.scaled = row.weight / scale; sum = sum + row.scaled end
    for _, row in ipairs(rows) do row.probability = row.scaled / sum; row.scaled = nil end
    return rows, true
end

function M.choose(fleet, available, random)
    local rows, enabled = M.probabilities(fleet, available)
    if not enabled then return nil end
    local value, cumulative, last = (random or math.random)(), 0, nil
    assert(M.finite(value) and value >= 0 and value < 1, "Random sample outside [0, 1)")
    for _, row in ipairs(rows) do
        if row.probability > 0 then
            last = row.id; cumulative = cumulative + row.probability
            if value < cumulative then return row.id end
        end
    end
    return last
end

return M
