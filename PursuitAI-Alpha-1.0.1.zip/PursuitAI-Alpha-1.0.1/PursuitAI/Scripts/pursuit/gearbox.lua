-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local M={}
-- Automatic transmission uses signed pedal input. Manual transmission uses
-- positive engine throttle in either selected gear; negative input produces no torque.
function M.command(state,telemetry,command,now)
    local throttle,brake=command.throttle,command.brake
    local direction=command.direction or (throttle<0 and -1 or 1)
    if telemetry.manual then throttle=math.abs(throttle) end
    local gear=telemetry.gear
    local moving=telemetry.forward_mps or 0
    -- A hold/settle/obstacle command must not select forward in the middle of reverse.
    if math.abs(throttle)<.01 and brake>=.65 then return nil,0,brake end
    if direction*moving < -.8 then return nil,0,1 end
    local shift
    local selecting=direction*gear<=0
    if direction<0 then
        if gear>-1 and telemetry.min_gear<0 then shift=-1 end
    elseif gear<1 then shift=1
    elseif brake<.2 then
        local upper=math.max(telemetry.max_rpm*.65,telemetry.ideal_max or 0)
        upper=math.min(upper,telemetry.max_rpm*.85)
        if telemetry.rpm>=upper and gear<telemetry.max_gear and moving>2 then shift=1
        elseif gear>1 and now-(state.last_upshift or -math.huge)>1.2 and telemetry.rpm<math.max(telemetry.max_rpm*.32,telemetry.ideal_min or 0) and math.abs(throttle)>.1 then shift=-1 end
    end
    if direction*gear<=0 then throttle=0 end
    if shift and now-(state.last_shift or -math.huge)>=(selecting and .18 or .65) then
        state.last_shift=now
        if shift>0 then state.last_upshift=now end
        return shift,throttle,brake
    end
    return nil,throttle,brake
end
return M
