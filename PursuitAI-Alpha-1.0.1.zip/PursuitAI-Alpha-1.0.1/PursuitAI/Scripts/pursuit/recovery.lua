-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local M={}
function M.begin(state,car,sensors,now,reason,steer)
    if state.recovery or sensors.rear<=2 or now<(state.recover_after or 0) then return false end
    state.recover_attempts=(state.recover_attempts or 0)+1
    state.recovery={started=now,x=car.x,y=car.y,yaw=car.yaw,steer=steer or 0,
        goal=math.min(3,sensors.rear-.8),reason=reason or "wall_recover"}
    return true
end
function M.step(state,car,sensors,now)
    local r=state.recovery;if not r then return nil end
    local dx,dy=car.x-r.x,car.y-r.y
    local retreat=-dx*math.cos(r.yaw)-dy*math.sin(r.yaw)
    if not r.moving_since and ((car.forward_mps or 0)<-.3 or retreat>.3) then r.moving_since=now end
    local reason
    if sensors.rear<.7 then reason="recovery_rear_blocked"
    elseif retreat>=r.goal or (r.moving_since and now-r.moving_since>=3) then reason="recovery_complete"
    elseif not r.moving_since and now-r.started>=8 then reason="recovery_no_motion" end
    if reason then
        state.recovery=nil;state.recover_after=now+1.5;state.blocked_since=nil;state.stuck_since=nil
        return {steering=0,throttle=0,brake=1,reason=reason}
    end
    return {steering=r.steer,throttle=-.6,brake=0,direction=-1,reason=r.reason}
end
return M
