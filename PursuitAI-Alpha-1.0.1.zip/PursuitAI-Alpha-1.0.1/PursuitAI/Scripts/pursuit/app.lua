-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local L=require('pursuit.i18n').text
return function(scripts,root)
local Defaults=require("config")
local Settings=require("pursuit.settings")
local Adapter=require("pursuit.adapter")
local Session=require("pursuit.session")
local Drive=require("pursuit.drive")
local Geometry=require("pursuit.geometry")
local Tactics=require("pursuit.tactics")
local Avoidance=require("pursuit.avoidance")
local Coordination=require("pursuit.coordination")
local Health=require("pursuit.health")
local Route=require("pursuit.route")
local Spawning=require("pursuit.spawning")
local Reinforcement=require("pursuit.reinforcement")
local Fleet=require("pursuit.fleet")
local Traffic=require("pursuit.traffic")
local Stability=require("pursuit.stability")
local Menu=require("pursuit.menu")
local Input=require("pursuit.input")
local cfg,config_error=Settings.load(root.."/settings.ini",Defaults)
if not cfg then
    print("[PursuitAI] Settings rejected; no gameplay enabled: "..tostring(config_error).."\n")
    return
end

require('pursuit.i18n').set(cfg.language)
local app={cfg=cfg,registration={},session=nil,driving=false,target_actor=nil,tactics={},ram_owner=nil,
    clock=nil,menu=nil,queued=false,tick_error_logged=false}

function app:message(text)
    print("[PursuitAI] "..tostring(text).."\n")
    self.status=tostring(text)
    if self.menu then pcall(self.menu.SetLabel,"Pursuit","status",self.status) end
end

function app:refresh_count()
    local count=0;for _ in pairs(self.registration) do count=count+1 end
    if self.menu then self.menu.SetLabel("Pursuit","count",L("Отмечено машин: ")..count) end
end

function app:dispatch(fn)
    -- All callers are game-thread timer/menu callbacks.
    local ok,err=pcall(fn)
    if not ok then self:message(tostring(err)) end
end
function app:refresh_players()
    self:probe()
    assert(self.adapter.ready,L('Список целей: нужна поддерживаемая версия игры и роль хоста'))
    local rows=self.adapter:players()
    local options={}
    options[#options+1]={label=L('Я — моя текущая машина'),value='__self'}
    for i,row in ipairs(rows) do options[#options+1]={label=row.label..' · '..i,value=row.key} end
    if #options==0 then options[1]={label=L('Нет подключённых игроков — обнови список'),value='__none'} end
    local selected=self.adapter.selected_player and self.adapter.selected_player.key or '__self'
    local present=false;for _,option in ipairs(options) do if option.value==selected then present=true end end
    if not present then table.insert(options,1,{label=L('Выбери игрока'),value='__none'});selected='__none' end
    if self.menu then self.menu.SetOptions('Pursuit','target',options,selected) end
    self:message(L('Список игроков обновлён. Выбери цель, затем начни погоню.'))
    return rows
end
function app:select_target_player(key)
    if key=='__none' then return end
    if self.session and self.session.state=='running' then self:stop() end
    local row=self.adapter:select_player(key)
    self:message(L('Цель: ')..(row and row.label or L('моя текущая машина'))..L('. Нажми «Начать погоню».'))
end

function app:trace(stage)
    local file=io.open(root.."/runtime_trace.log","a")
    if file then file:write(os.date("!%Y-%m-%dT%H:%M:%SZ")," ",stage,"\n");file:close() end
end
app.adapter=Adapter.new(cfg,function(text) app:message(text) end,function(stage) app:trace(stage) end)

function app:probe()
    if self.session and self.session.state=="running" then self:stop() end
    self.driving=false
    local report,ready=self.adapter:probe()
    local file=io.open(root.."/diagnostics.txt","w")
    if file then file:write(report);file:close() end
    print("[PursuitAI]\n"..report)
    self:message(ready and L("Нужные функции найдены. Поведение машин ещё требует проверки.") or L("Проверка не пройдена. Отчёт: PursuitAI/diagnostics.txt"))
end

function app:set_driving(on)
    if on then
        assert(self.adapter.ready,L("Сначала нужна успешная проверка совместимости"))
        self.driving=true;self:message(L("Тестовое управление разрешено до перезапуска мода."))
    else self.driving=false;self:stop() end
end

function app:register_current()
    self:trace("register:begin")
    if not self.adapter.ready then self:probe() end
    assert(self.adapter.ready,L("Сначала нужна успешная проверка совместимости"))
    assert(not self.session or self.session.state~="running",L("Сначала останови погоню"))
    self:trace("register:current_vehicle:before")
    local vehicle=self.adapter:current_vehicle()
    self:trace("register:current_vehicle:after")
    self:trace("register:display_name:before")
    local display=vehicle:GetVehicleDisplayName():ToString()
    self:trace("register:display_name:after")
    local model_id=nil
    for _,model in ipairs(self.cfg.fleet) do if display==model.name then model_id=model.id;break end end
    -- Unknown vehicles can still be used for a manual test. Never guess their fleet identity.
    local item=self.adapter:register_current(model_id,vehicle)
    self.registration[item.key]=item
    self:refresh_count()
    self:message(L("Машина отмечена. Выйди из неё и сядь в машину гонщика. ")..display)
    self:trace("register:complete")
end

function app:start()
    if self.session and self.session.state=="running" then self:message(L("Погоня уже идёт."));return end
    self:probe()
    assert(self.adapter.ready,L("Эта версия игры или режим пока не поддерживается. Подробности — в настройках."))
    self.driving=true
    assert(not self.session or not self:cleanup_pending(),L("Дождись уборки повреждённых машин или нажми сброс"))
    local target,target_seat=self.adapter:target_vehicle();local target_key=self.adapter:key(target)
    assert(not self.registration[target_key],L("Машина гонщика отмечена как полицейская; нужен сброс"))
    local initial={}
    for key,item in pairs(self.registration) do
        local registered=self.adapter.vehicles[key]
        assert(registered and Adapter.valid(registered.actor),L("Одна из отмеченных машин уже удалена; нужен сброс"))
        assert(not self.adapter:occupied(registered.actor),L("Все отмеченные полицейские машины должны быть пустыми"))
        assert(not self.adapter:observe(key).disabled,L("Отмеченная машина повреждена; нужен сброс"))
        initial[#initial+1]=item
    end
    assert(#initial>0,L("Сначала отметь хотя бы одну полицейскую машину"))
    local prepared,prepare_error=pcall(function()
        for _,unit in ipairs(initial) do self.adapter:prepare_driver(unit.key) end
    end)
    if not prepared then self.adapter:release_all();error(prepare_error) end
    self.spawner=Spawning.new(self.adapter)
    self.available_models=self.cfg.session.reinforcements_enabled and self.adapter.reinforcements_ready and self.cfg.session.reserve>0 and self.spawner:pool() or {}
    self.session=Session.new(self.cfg.session,self.cfg.fleet)
    local _,eligible=Fleet.probabilities(self.cfg.fleet,self.available_models)
    if not eligible then self.session.reserve=0 end
    self.initial_count=#initial;self.health={};self.failed_launches={};self.next_reinforcement=nil
    local now=self.adapter:now()
    local started,reason=self.session:start(initial,{key=target_key},now)
    assert(started,reason)
    self.clock=now;self.target_actor=target;self.target_seat=target_seat;self.tick_error_logged=false
    self.tactics={};self.traffic={};self.ram_owner=nil;self.owner_since=nil
    self:message(L("Погоня началась. Копы знают положение машины гонщика."))
    if self.adapter.multiplayer then self:message(L('Погоня хоста началась: ')..(self.adapter.selected_player and self.adapter.selected_player.label or L('Я'))..L('. Запас подкреплений: ')..self.session.reserve) end
end

function app:cleanup_pending()
    if not self.session then return false end
    for _,u in pairs(self.session.units) do if u.state=="disabled" then return true end end
    return false
end

function app:stop()
    if self.spawner then self.spawner:discard() end
    if self.session then self.session:cancel("stopped_by_player") end
    self.adapter:release_all()
    self.tactics={};self.traffic={};self.ram_owner=nil;self.owner_since=nil
end

function app:reset()
    self:stop();self.adapter:reset();self.session=nil;self.target_actor=nil;self.registration={}
    self:refresh_count()
    self:message(L("Отметки сброшены. Оставшиеся машины можно убрать обычными средствами игры."))
end

function app:tick()
    if not self.session then return end
    if self.session.state~="running" and not self:cleanup_pending() then return end
    if not self.adapter:can_host() then self:stop();self:message(L('Управление остановлено: этот клиент больше не хост.'));return end
    if self.session.state=='running' and not self.adapter:target_connected() then self:stop();self:message(L('Выбранный игрок отключился. Выбери цель заново.'));return end
    local now=self.adapter:now()
    if now<self.clock then self:reset();return end -- map changed; never reuse old object handles
    self.clock=now
    local target_available=false
    if self.session.state=="running" then
        local ok,current,seat=pcall(function() return self.adapter:target_vehicle() end)
        if ok and not self.session.units[self.adapter:key(current)] then
            local sampled,frame=pcall(function() return self.adapter:snapshot(current,seat) end)
            if sampled then
                target_available=true;self.target_seat=seat
                if self.session.target.key~=frame.key or self.target_paused then
                    self.target_actor=current;self.session.target.key=frame.key
                    self.tactics={};self.traffic={};self.ram_owner=nil;self.owner_since=nil;self.health={}
                    if self.spawner then self.spawner:discard() end
                    self.session.pending=nil;self:trace("target:reacquired:"..frame.key)
                end
            end
        end
        self.target_paused=not target_available
    end
    local observations={}
    for key,unit in pairs(self.session.units) do
        if unit.state=="active" and self.session.state=="running" then
            local ok,err=pcall(function() self.adapter:refresh_binding(key,now) end)
            if not ok then self:trace("driver:binding_retry:"..key..":"..tostring(err)) end
        end
        observations[key]=self.adapter:observe(key)
        if unit.state=="active" and self.session.state=="running" and target_available and not observations[key].disabled and not observations[key].pending then
            local car=self.adapter:snapshot(self.adapter.vehicles[key].actor)
            self.health[key]=self.health[key] or {}
            local reason=Health.update(self.health[key],car,self.tactics[key] or {},self.cfg.session,now)
            if reason and self.adapter:retire(key,reason) then observations[key]={disabled=true,reason=reason} end
        end
    end
    local due=self.session:update(now,observations,true)
    for _,key in ipairs(due) do
        local ok,removed=pcall(function() return self.adapter:cleanup(key) end)
        self.session:cleanup_ack(key,ok and removed)
        if ok and removed then self.registration[key]=nil;self:refresh_count() end
    end
    if self.session.state=="running" and not target_available then
        if self.spawner then self.spawner:discard() end
        self.session.pending=nil
        for key,unit in pairs(self.session.units) do
            if unit.state=="active" then
                local item=self.adapter.vehicles[key]
                if item and Adapter.valid(item.actor) and not self.adapter:occupied(item.actor) then
                    pcall(function() self.adapter:apply(key,{steering=0,throttle=0,brake=1},now) end)
                end
            end
        end
    elseif self.session.state=="running" then
        local target=self.adapter:snapshot(self.target_actor,self.target_seat)
        Reinforcement.tick(self,target,now)
        local cars,ordered={},{}
        for key,unit in pairs(self.session.units) do
            if unit.state=="active" and (not observations[key] or not observations[key].pending) then
                local item=self.adapter.vehicles[key]
                local car=self.adapter:snapshot(item.actor)
                local applied=self.adapter.drivers[key] and self.adapter.drivers[key].last_applied
                if applied then car.applied_gear=applied.gear;car.applied_rpm=applied.rpm;car.applied_throttle=applied.throttle end
                cars[key]=car;ordered[#ordered+1]=car
            elseif unit.state~="active" then self.adapter:release(key) end
        end
        table.sort(ordered,function(a,b) return a.key<b.key end)
        local obstacles=ordered
        local pending=self.spawner and self.spawner.pending
        if pending and pending.key and Adapter.valid(pending.actor) then
            obstacles={};for _,car in ipairs(ordered) do obstacles[#obstacles+1]=car end
            obstacles[#obstacles+1]=self.adapter:snapshot(pending.actor)
        end
        Coordination.assign(self,ordered,target,now)
        for rank,car in ipairs(ordered) do car.priority=car.key==self.ram_owner and 0 or rank end
        local traffic_commands=Traffic.plan(self.traffic,ordered,now,function(car)
            self.traffic.probes=self.traffic.probes or {}
            local cached=self.traffic.probes[car.key]
            if not cached or now-cached.at>.4 then
                cached={at=now,value=self.adapter:sensors(car.key,car,self.target_actor,{steering=0,throttle=0,allow_target_contact=false},now)}
                self.traffic.probes[car.key]=cached
            end
            return cached.value
        end,function(event) self:trace(event) end)
        for rank,car in ipairs(ordered) do
            local key=car.key
            local unit_ok,unit_error=pcall(function()
            if not self.adapter.drivers[key] then self.adapter:prepare_driver(key) end
            self.tactics[key]=self.tactics[key] or {}
            local state=self.tactics[key];local before=state.phase
            local context={attacker=not self.ram_owner or self.ram_owner==key,rank=rank}
            local aim_target=self.adapter:prediction_target(car,target,self.target_actor,now)
            local command=Tactics.command(state,car,aim_target,self.cfg.drive,now,context)
            local gap=math.max(0,Geometry.gap(car,target))
            local angle=(math.atan(target.y-car.y,target.x-car.x)-car.yaw+math.pi)%(2*math.pi)-math.pi
            -- A short straight final approach: do not let lead, cover handoff or
            -- skid correction turn a lined-up ram into a last-second dodge.
            if context.attacker and state.phase~='backoff' and state.phase~='settle' and state.phase~='align'
                and not command.direction and gap<8 and math.abs(angle)<.45 then
                command=Drive.command(car,{x=target.x,y=target.y,vx=0,vy=0},self.cfg.drive,nil,state)
                command.ramming=true;command.ram_committed=true;command.ram_contact_distance=gap
            end
            local requested_steering=command.steering or 0
            if before=="backoff" and state.phase=="settle" then state.attack_completed=true end
            command.allow_target_contact=context.attacker
            command=traffic_commands[key] or command
            local sensors=self.adapter:sensors(key,car,self.target_actor,command,now)
            if not command.traffic_wait and not command.traffic_escape then command=Route.command(state,car,command,sensors,self.cfg.drive,now,target) end
            command=Stability.command(state,car,command,self.cfg.drive,now)
            local direction=command.direction or (command.throttle<0 and -1 or 1)
            if direction~=sensors.planned_direction or math.abs((command.steering or 0)-(sensors.planned_steering or 0))>=.25 then
                sensors=self.adapter:sensors(key,car,self.target_actor,command,now)
            end
            command=Avoidance.command(car,obstacles,command,sensors,self.cfg.drive,state,now)
            state.last_command=command
            if state.phase~=before then self:trace("maneuver:"..key..":"..state.phase) end
            self.adapter:apply(key,command,now,car)
            if not state.report_at or now>=state.report_at then
                state.report_at=now+5
                local actual=self.adapter.drivers[key] and self.adapter.drivers[key].last_applied or {}
                local distance=math.sqrt((car.x-target.x)^2+(car.y-target.y)^2)
                self:trace(string.format("unit:%s speed=%.1f phase=%s reason=%s front=%.1f rear=%.1f gear=%s rpm=%.0f gas=%.2f brake=%.2f target_m=%.1f forward_mps=%.2f wanted_gas=%.2f handbrake=%s steer=%.3f wanted_steer=%.3f yaw=%.3f target_angle=%.3f",key,
                    car.speed_mps*3.6,state.phase or "unknown",command.reason or "unknown",sensors.front,sensors.rear,
                    tostring(actual.gear),actual.rpm or 0,actual.throttle or 0,actual.brake or 0,distance,
                    actual.forward_mps or 0,actual.requested_throttle or 0,tostring(actual.handbrake),
                    command.steering or 0,requested_steering,car.yaw,
                    (math.atan(target.y-car.y,target.x-car.x)-car.yaw+math.pi)%(2*math.pi)-math.pi))
            end
            end)
            if not unit_ok then
                self.adapter:release(key)
                local state=self.tactics[key] or {};self.tactics[key]=state
                if now>=(state.error_at or 0) then
                    state.error_at=now+5;self:trace("unit:control_retry:"..key..":"..tostring(unit_error))
                end
            end
        end
    else
        if self.spawner then self.spawner:discard() end
        self.adapter:release_all()
    end
    while #self.session.events>0 do
        local event=table.remove(self.session.events,1)
        if event.kind=="cleaned" then self:trace("cleanup:confirmed:"..tostring(event.detail))
        elseif event.kind=="won" then self:message(L("Победа: все копы выведены из строя."))
        elseif event.kind=="cancelled" then self:message(L("Погоня остановлена: ")..tostring(event.detail))
        elseif event.kind=="disabled" then
            local key=event.detail;local evidence=observations[key]
            self:trace("unit_disabled:"..tostring(key)..":"..tostring(evidence and evidence.reason))
            self:message(L("Коп выведен из строя. Уборка после задержки.")) end
    end
end

app.input=Input.new(app.adapter,function(text) app:message(text) end)
app.input:bind("F6",function() app:dispatch(function() app:probe() end) end)
app.input:bind("F5",function() app:dispatch(function() app:set_driving(not app.driving) end) end)
app.input:bind("F7",function() app:dispatch(function() app:register_current() end) end)
app.input:bind("F9",function() app:dispatch(function() app:start() end) end)
app.input:bind("F10",function() app:dispatch(function() app:stop();app:message(L("Погоня остановлена.")) end) end)
app.input:bind("F11",function() app:dispatch(function() app:reset() end) end)

local menu_ok,menu_result=pcall(Menu.attach,app,root)
if menu_ok then app.menu=menu_result else app:message(L("Меню недоступно: ")..tostring(menu_result)) end

assert(type(LoopInGameThreadWithDelay)=="function","This build requires game-thread timers")
app.input_callback=function()
    if app.pending_language then
        local language=app.pending_language;app.pending_language=nil
        require('pursuit.i18n').set(language)
        if app.menu and app.menu.Close then app.menu.Close() end
        app.locale_rebuild=true
        return -- let the game-thread close finish before rebuilding widgets
    end
    if app.locale_rebuild then
        app.locale_rebuild=nil
        local ok,menu=pcall(Menu.attach,app,root)
        if ok and menu then
            app.menu=menu
            if menu.Set then menu.Set('Options','language',app.cfg.language) end
            if menu.SetTab then menu.SetTab(L('Настройки')) end
            app:refresh_count()
            app:message(L('Настройки сохранены.'))
            if menu.Open then menu.Open() end
        else app:message('Language menu refresh failed: '..tostring(menu)) end
    end
    app.input:poll()
end
app.tick_callback=function()
    local began=os.clock()
    local ok,err=pcall(function() app:tick() end)
    if app.session and app.session.state=="running" then
        local elapsed=(os.clock()-began)*1000
        local p=app.performance or {n=0,total=0,max=0};app.performance=p
        p.n=p.n+1;p.total=p.total+elapsed;p.max=math.max(p.max,elapsed)
        if p.n>=50 then
            app:trace(string.format("performance: ticks=%d mean_ms=%.2f max_ms=%.2f",p.n,p.total/p.n,p.max))
            app.performance=nil
        end
    end
    if not ok then
        app:stop()
        if not app.tick_error_logged then
            app.tick_error_logged=true;app:message(L("Тест остановлен: ")..tostring(err))
        end
    end
end
-- Strong references remain in the retained app for the entire mod lifetime.
app.input_timer=LoopInGameThreadWithDelay(50,app.input_callback)
app.tick_timer=LoopInGameThreadWithDelay(Defaults.tick_ms,app.tick_callback)

app:message(L("F8 — меню. Сядь в машину копа и нажми «Отметить машину»."))

return app
end
