-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local Fleet = require("pursuit.fleet")
local SpawnPolicy = require("pursuit.spawn_policy")
local M = {}; M.__index = M

function M.new(cfg, fleet, random)
    assert(cfg.reserve >= 0 and cfg.reserve%1 == 0, "Invalid reserve")
    return setmetatable({cfg=cfg, fleet=fleet, random=random or math.random,
        state="idle", units={}, reserve=cfg.reserve, pending=nil,
        replacement_slots=0, sequence=0, events={}, clock=0},M)
end

function M:event(kind, detail)
    self.events[#self.events+1] = {kind=kind, detail=detail}
end

function M:start(initial, target, now)
    if self.state ~= "idle" then return false,"session_already_started" end
    if not target or #initial == 0 then return false,"target_and_police_required" end
    local units = {}
    for _, item in ipairs(initial) do
        if not item.key or units[item.key] or item.key == target.key then return false,"invalid_initial_police" end
        units[item.key] = {key=item.key, model_id=item.model_id, state="active", owned=item.owned == true}
    end
    self.units=units; self.target=target; self.state="running"; self.clock=now
    self:event("started",#initial)
    return true
end

function M:active_count()
    local n=0;for _,u in pairs(self.units) do if u.state=="active" then n=n+1 end end;return n
end

function M:cancel(reason)
    if self.state ~= "running" then return end
    self.pending=nil; self.state="cancelled";self:event("cancelled",reason)
end

function M:update(now, evidence, target_available)
    assert(type(now)=="number" and now>=self.clock,"Clock must be monotonic")
    self.clock=now
    if self.pending and now>=self.pending.expires then
        self.pending=nil;self:event("spawn_expired")
    end
    if self.state=="running" then
        if not target_available then self:cancel("target_unavailable") end
        if self.state=="running" then
            for key,u in pairs(self.units) do
                local observation=evidence[key]
                -- Damage evidence must be positive; nil/unknown is never a kill.
                if u.state=="active" and observation and observation.disabled==true then
                    u.state="disabled";u.disabled_at=now;u.cleanup_after=now+self.cfg.cleanup_delay_s
                    self.replacement_slots=self.replacement_slots+1
                    self:event("disabled",key)
                end
            end
            if self.reserve==0 and not self.pending and self:active_count()==0 then
                self.state="won";self:event("won")
            end
        end
    end
    -- Cleanup remains live after victory/cancellation. Only explicit acknowledgements remove units.
    local due={}
    for key,u in pairs(self.units) do
        if u.state=="disabled" and now>=u.cleanup_after and (not u.retry_after or now>=u.retry_after) then
            due[#due+1]=key;u.retry_after=now+self.cfg.cleanup_retry_s
        end
    end
    return due
end

function M:cleanup_ack(key, success)
    local u=self.units[key]
    if success and u and u.state=="disabled" then u.state="removed";self:event("cleaned",key) end
end

function M:request_spawn(now, candidate, player, role, available)
    if self.state~="running" or self.pending or self.reserve==0 or self.replacement_slots==0 then return nil,"not_needed" end
    local allowed, reason=SpawnPolicy.allowed(candidate,player,role,self.cfg.spawn)
    if not allowed then return nil,reason end
    local model=Fleet.choose(self.fleet,available,self.random)
    if not model then return nil,"empty_fleet" end
    self.sequence=self.sequence+1
    self.pending={token=self.sequence,model_id=model,candidate=candidate,expires=now+self.cfg.spawn_timeout_s}
    return self.pending
end

-- A successful acknowledgement means fully constructed + usable + hidden + collision-free.
-- Asynchronous requests do not consume reserves before that confirmation.
function M:spawn_ack(token, key, success, now)
    local pending=self.pending
    if not pending or pending.token~=token then return false,"stale_token" end
    self.pending=nil
    if now>=pending.expires or self.state~="running" then return false,"expired_or_cancelled" end
    if not success then return false,"spawn_failed" end
    if not key or self.units[key] or key==self.target.key then return false,"invalid_spawned_vehicle" end
    self.units[key]={key=key,model_id=pending.model_id,state="active",owned=true}
    self.reserve=self.reserve-1;self.replacement_slots=self.replacement_slots-1
    self:event("reinforced",key)
    return true
end

return M
