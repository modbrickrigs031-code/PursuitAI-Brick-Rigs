-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local Fleet=require("pursuit.fleet")
local M={}
local function copy(t)
    if type(t)~="table" then return t end
    local r={};for k,v in pairs(t) do r[k]=copy(v) end;return r
end

-- Data only: this INI reader never executes user settings as Lua code.
function M.load(path,defaults)
    local result=copy(defaults)
    local f=io.open(path,"r");if not f then return result end
    local section,seen="",{}
    local byid={};for _,v in ipairs(result.fleet) do byid[v.id]=v end
    local ok,err=pcall(function()
        for line in f:lines() do
            line=line:gsub("\r$",""):match("^%s*(.-)%s*$")
            if line~="" and not line:match("^[;#]") then
                local header=line:match("^%[([%w_]+)%]$")
                if header then section=header else
                    local key,value=line:match("^([%w_]+)%s*=%s*(.-)%s*$")
                    assert(key,"Malformed settings line")
                    local unique=section.."."..key;assert(not seen[unique],"Duplicate setting: "..unique);seen[unique]=true
                    if section=="general" and key=="language" then
                        assert(value=='en' or value=='ru','Invalid language');result.language=value
                    elseif section=="general" and key=="speed_limit_version" then
                        assert(value=='1','Invalid speed_limit_version')
                    elseif section=="general" and key=="reinforcements_enabled" then
                        assert(value=='true' or value=='false','Invalid reinforcements_enabled');result.session.reinforcements_enabled=value=='true'
                    elseif section=="weights" or section=="clearance_m" then
                        assert(byid[key],"Unknown model: "..key)
                        local n=tonumber(value)
                        if section=="clearance_m" and value=="unknown" then n=nil
                        else assert(Fleet.finite(n) and n>=0,"Invalid number: "..unique) end
                        if section=="weights" then byid[key].weight=n end -- Old clearance values are accepted and discarded for compatibility.
                    elseif section=="enabled" then
                        assert(byid[key] and (value=="true" or value=="false"),"Invalid enabled model setting")
                        byid[key].enabled=value=="true"
                    elseif section=="general" and key=="immobilized_cleanup" then
                        assert(value=="true" or value=="false","Invalid immobilized_cleanup")
                        result.session.immobilized_cleanup=value=="true"
                    elseif section=="general" and (key=="reserve" or key=="reinforcement_delay_s" or key=="overturned_after_s" or key=="stuck_after_s") then
                        local bounds={reserve={0,50},reinforcement_delay_s={3,60},overturned_after_s={3,30},stuck_after_s={20,120}}
                        local n=tonumber(value);local b=bounds[key]
                        assert(Fleet.finite(n) and n>=b[1] and n<=b[2] and (key~="reserve" or n%1==0),"Invalid general setting: "..key)
                        result.session[key]=n
                    elseif section=="general" and key=="cleanup_delay_s" then
                        local n=tonumber(value);assert(Fleet.finite(n) and n>=5 and n<=600,"cleanup_delay_s outside 5..600")
                        result.session.cleanup_delay_s=n
                    elseif section=="driving" and key=="aggression" then
                        local n=tonumber(value);assert(Fleet.finite(n) and n>=.5 and n<=2,"Invalid aggression")
                        result.drive.aggression=n
                    elseif section=="driving" and (key=="ram_enabled" or key=="sirens_enabled" or key=="beacons_enabled" or key=="stability_enabled") then
                        assert(value=="true" or value=="false","Invalid ram_enabled setting")
                        result.drive[key]=value=="true"
                    elseif section=="driving" and (key=="ram_retreat_m" or key=="ram_speed_kmh" or key=="cruise_kmh") then
                        local n=tonumber(value)
                        local low,high=key=="ram_retreat_m" and 5 or 30,key=="ram_retreat_m" and 35 or (key=="cruise_kmh" and 500 or 70)
                        assert(Fleet.finite(n) and n>=low and n<=high,"Invalid driving setting: "..key)
                        result.drive[key]=n
                    else error("Unknown setting: "..unique) end
                end
            end
        end
    end)
    f:close()
    if not ok then return nil,err end
    -- Preserve the old combined checkbox until the new light option is set.
    if seen["driving.sirens_enabled"] and not seen["driving.beacons_enabled"] then result.drive.beacons_enabled=result.drive.sirens_enabled end
    -- First load of pre-hotfix settings upgrades the old artificial cruise cap.
    -- Once saved with this revision, explicit user speed choices are preserved.
    if not seen['general.speed_limit_version'] then result.drive.cruise_kmh=500 end
    return result
end

function M.save(path,cfg)
    Fleet.probabilities(cfg.fleet)
    local lines={"; PursuitAI settings: weights are normalized; zero disables a model.","[general]",
        "speed_limit_version=1","language="..cfg.language,"reinforcements_enabled="..tostring(cfg.session.reinforcements_enabled),
        "cleanup_delay_s="..tostring(cfg.session.cleanup_delay_s),
        "reserve="..tostring(cfg.session.reserve),"reinforcement_delay_s="..tostring(cfg.session.reinforcement_delay_s),
        "overturned_after_s="..tostring(cfg.session.overturned_after_s),"stuck_after_s="..tostring(cfg.session.stuck_after_s),
        "immobilized_cleanup="..tostring(cfg.session.immobilized_cleanup),"","[driving]",
        "aggression="..tostring(cfg.drive.aggression),
        "sirens_enabled="..tostring(cfg.drive.sirens_enabled),"beacons_enabled="..tostring(cfg.drive.beacons_enabled),"stability_enabled="..tostring(cfg.drive.stability_enabled),
        "ram_enabled="..tostring(cfg.drive.ram_enabled),"ram_retreat_m="..tostring(cfg.drive.ram_retreat_m),
        "ram_speed_kmh="..tostring(cfg.drive.ram_speed_kmh),"cruise_kmh="..tostring(cfg.drive.cruise_kmh),"","[weights]"}
    for _,v in ipairs(cfg.fleet) do lines[#lines+1]=v.id.."="..string.format("%.17g",v.weight) end
    lines[#lines+1]="";lines[#lines+1]="[enabled]"
    for _,v in ipairs(cfg.fleet) do lines[#lines+1]=v.id.."="..tostring(v.enabled) end
    local temporary=path..".tmp"
    local f,err=io.open(temporary,"w");if not f then return false,err end
    local wrote,write_err=f:write(table.concat(lines,"\n").."\n")
    local closed,close_err=f:close()
    if not wrote or not closed then return false,write_err or close_err end
    local old=io.open(path,"r");local backup=nil
    if old then
        old:close();backup=path..".backup-"..tostring(os.time())
        local n=0
        while true do
            local probe=io.open(backup,"r")
            if not probe then break end
            probe:close();n=n+1;backup=path..".backup-"..tostring(os.time()).."-"..n
        end
        local moved,move_err=os.rename(path,backup)
        if not moved then return false,move_err end
    end
    local replaced,replace_err=os.rename(temporary,path)
    if not replaced then
        if backup then os.rename(backup,path) end
        return false,replace_err
    end
    return true,backup
end

return M
