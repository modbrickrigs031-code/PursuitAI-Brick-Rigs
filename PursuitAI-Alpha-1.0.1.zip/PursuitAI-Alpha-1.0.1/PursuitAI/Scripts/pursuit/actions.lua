-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local M={}
function M.real_mode(enum,to_string)
    if not enum then return nil end
    local mode
    local ok=pcall(function()
        enum:ForEachName(function(name,value)
            if to_string(name):match('([^:]+)$')=='Real' then mode=value end
        end)
    end)
    if ok and type(mode)=='number' and mode>=0 and mode%1==0 then return mode end
end
function M.params(real_mode,secondary)
    assert(type(real_mode)=='number','EBrActionMode::Real is unavailable; refusing a guessed action mode')
    return {Mode=real_mode,AxisValue=1,bIsSecondaryAction=secondary==true}
end
return M
