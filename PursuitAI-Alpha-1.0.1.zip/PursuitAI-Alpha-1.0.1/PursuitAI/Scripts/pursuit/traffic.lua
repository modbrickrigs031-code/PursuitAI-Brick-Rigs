-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local G=require('pursuit.geometry')
local M={}
local function curvature(c,steer) return math.tan(steer*.5)/math.max(2,math.min(6,(c.half_length_m or 2.5)*1.2)) end
local function pose(c,direction,steer,d)
    local p={};for k,v in pairs(c) do p[k]=v end
    local curvature=curvature(c,steer)
    local travel=d*direction;local angle=curvature*travel
    local dx,dy
    if math.abs(curvature)<.001 then dx=math.cos(c.yaw)*travel;dy=math.sin(c.yaw)*travel
    else dx=(math.sin(c.yaw+angle)-math.sin(c.yaw))/curvature;dy=(math.cos(c.yaw)-math.cos(c.yaw+angle))/curvature end
    p.x=c.x+dx;p.y=c.y+dy;p.yaw=c.yaw+angle
    if c.center then
        local ox,oy=c.center.X/100-c.x,c.center.Y/100-c.y
        p.center={X=(p.x+ox*math.cos(angle)-oy*math.sin(angle))*100,Y=(p.y+ox*math.sin(angle)+oy*math.cos(angle))*100,Z=c.center.Z}
    end
    return p
end
function M.path_clear(car,other,direction,steer,distance)
    local initial=G.gap(car,other);local last=initial
    local samples=math.max(6,math.ceil(distance/.25))
    for i=1,samples do
        local gap=G.gap(pose(car,direction,steer,distance*i/samples),other)
        if initial<=.1 then
            if gap<last-.04 then return false end
        elseif gap<math.min(.15,initial-.03) then return false end
        last=gap
    end
    return initial>.1 or last>initial+math.min(.25,math.max(.02,distance*.4))
end
local function travel(lock,c)
    if not c then return math.huge end
    local yaw=lock.yaw or c.yaw;local dx,dy=c.x-lock.x,c.y-lock.y
    local along=dx*math.cos(yaw)+dy*math.sin(yaw)
    local lateral=-dx*math.sin(yaw)+dy*math.cos(yaw)
    local k=lock.curvature or 0
    local signed=math.abs(k)<.001 and along or math.atan(k*along,1-k*lateral)/k
    return math.max(0,signed*lock.direction)
end
local function path_id(direction,steer) return tostring(direction)..':'..tostring(steer) end
function M.plan(s,cars,now,probe,report)
    report=report or function() end
    local bykey={};for _,c in ipairs(cars) do bykey[c.key]=c end
    local lock=s.lock
    if lock then
        local c=bykey[lock.key]
        local moved=travel(lock,c)
        if c and moved>(lock.progress or 0)+.2 then lock.progress=moved;lock.progress_at=now end
        if not c or moved>=lock.distance or now-lock.started>10 or now-(lock.progress_at or lock.started)>4 then
            if c and moved<lock.distance then
                s.failed=s.failed or {};s.failed[lock.key]=now+5
                s.failed_paths=s.failed_paths or {};s.failed_paths[lock.key]=s.failed_paths[lock.key] or {}
                s.failed_paths[lock.key][path_id(lock.direction,lock.steer)]=now+20
                -- A gear number alone is not motion. Suppress repeated idle
                -- reverse requests on this car, without changing saved settings.
                if lock.direction<0 and c.applied_gear and c.applied_gear<0 and
                    math.abs(c.applied_throttle or 0)>.2 and (c.applied_rpm or math.huge)<700 and c.speed_mps<.4 then
                    s.failed_reverse=s.failed_reverse or {};s.failed_reverse[lock.key]=now+20
                end
                report('traffic:failed:'..lock.key..':direction='..lock.direction..':steer='..lock.steer..':progress='..string.format('%.2f',moved))
            else report('traffic:complete:'..lock.key) end
            s.handoff_members=lock.members
            s.lock=nil;s.next_at=now+.5;lock=nil
        end
    end
    if not lock and now>=(s.next_at or 0) then
        local members={};local seed
        for i,a in ipairs(cars) do
            for j=i+1,#cars do
                local b=cars[j]
                if a.speed_mps<1.5 and b.speed_mps<1.5 and G.gap(a,b)<.6 then seed=a.key;break end
            end
            if seed then break end
        end
        if not seed then s.jam_since=nil;return {} end
        members[seed]=true
        for _=1,#cars do
            for _,a in ipairs(cars) do if members[a.key] then
                for _,b in ipairs(cars) do if b.speed_mps<1.5 and G.gap(a,b)<.8 then members[b.key]=true end end
            end end
        end
        s.jam_since=s.jam_since or now
        if now-s.jam_since<.8 then return {} end
        local best=-math.huge
        for _,c in ipairs(cars) do if members[c.key] and now>=((s.failed or {})[c.key] or 0) then
            local sensors=probe(c)
            if sensors and sensors.valid then
                -- Three metres cannot clear two cars touching side by side:
                -- the hulls remain alongside for most of a full car length.
                local long_step=3;local fx,fy=math.cos(c.yaw),math.sin(c.yaw)
                for _,other in ipairs(cars) do
                    if other.key~=c.key and members[other.key] then
                        local offset=math.abs((other.x-c.x)*fx+(other.y-c.y)*fy)
                        long_step=math.max(long_step,math.min(8,offset+G.support(c,fx,fy)+G.support(other,fx,fy)+1))
                    end
                end
                for _,direction in ipairs({1,-1}) do
                    local reverse_blocked=direction<0 and now<((s.failed_reverse or {})[c.key] or 0)
                    if not reverse_blocked then
                    local clear=direction<0 and sensors.rear or sensors.front
                    for _,step in ipairs({long_step,3,1.5,.8}) do
                    local distance=math.min(step,clear-.4)
                    if distance>.65 then
                        for _,steer in ipairs({0,-.65,.65}) do
                            local until_at=((s.failed_paths or {})[c.key] or {})[path_id(direction,steer)] or 0
                            local safe=now>=until_at
                            for _,other in ipairs(cars) do
                                if other.key~=c.key and not M.path_clear(c,other,direction,steer,distance) then safe=false;break end
                            end
                            local score=math.min(distance,3)-math.max(0,distance-3)*.25+
                                (direction>0 and 4 or 0)-math.abs(steer)*.3
                            if safe and score>best then
                                best=score;lock={key=c.key,direction=direction,steer=steer,distance=distance,
                                    started=now,x=c.x,y=c.y,yaw=c.yaw,curvature=curvature(c,steer),members=members}
                            end
                        end
                    end
                    end
                    end
                end
            end
        end end
        s.lock=lock
        if lock then
            s.handoff_members=nil
            report('traffic:start:'..lock.key..':direction='..lock.direction..':steer='..lock.steer..':distance='..string.format('%.2f',lock.distance))
        end
    end
    local commands={}
    if not lock then
        -- The half-second handoff is a stop, not permission for the whole jam
        -- to accelerate independently before the next owner is chosen.
        if now<(s.next_at or 0) then
            for key in pairs(s.handoff_members or {}) do
                if bykey[key] then commands[key]={steering=0,throttle=0,brake=1,reason='traffic_wait',traffic_wait=true,allow_target_contact=false} end
            end
        else s.handoff_members=nil end
        return commands
    end
    for key in pairs(lock.members) do
        local c=bykey[key]
        if c then
            if key==lock.key then
                commands[key]={steering=lock.steer,throttle=c.speed_mps<2 and lock.direction*.45 or 0,
                    brake=c.speed_mps>2.5 and .6 or 0,direction=lock.direction,reason='traffic_escape',
                    traffic_escape=true,escape_remaining=math.max(.1,lock.distance-travel(lock,c)),traffic_members=lock.members,allow_target_contact=false}
            else commands[key]={steering=0,throttle=0,brake=1,reason='traffic_wait',traffic_wait=true,allow_target_contact=false} end
        end
    end
    return commands
end
return M
