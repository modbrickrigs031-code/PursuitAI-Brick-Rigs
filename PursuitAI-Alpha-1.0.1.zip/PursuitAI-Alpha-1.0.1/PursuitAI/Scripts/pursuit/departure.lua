-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local M={}
function M.ready(state,car,target)
    if not state.x then
        local dx,dy=target.x-car.x,target.y-car.y;local length=math.max(.01,math.sqrt(dx*dx+dy*dy))
        state.x=car.x;state.y=car.y;state.fx=dx/length;state.fy=dy/length
    end
    local progress=(car.x-state.x)*state.fx+(car.y-state.y)*state.fy
    return progress>=1.5 and car.speed_mps>.5,progress
end
return M
