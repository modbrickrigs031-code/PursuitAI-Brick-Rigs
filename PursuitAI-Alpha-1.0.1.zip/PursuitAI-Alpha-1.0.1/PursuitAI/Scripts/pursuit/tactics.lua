-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local Drive=require("pursuit.drive")
local Geometry=require("pursuit.geometry")
local M={}
local function clamp(x,a,b) return math.max(a,math.min(b,x)) end
local function norm(x,y) local d=math.sqrt(x*x+y*y);if d<.01 then return 1,0,0 end;return x/d,y/d,d end
local function phase(s,name,now)
    if s.phase~=name then s.drive_reverse=nil end
    s.phase=name;s.since=now;s.contact_since=nil;s.contact_at=nil;s.contact_min=nil;s.contact_last=nil
    s.backoff_direction=nil;s.backoff_moving=nil;s.backoff_x=nil;s.backoff_y=nil
end
local function brake(reason) return {steering=0,throttle=0,brake=1,reason=reason} end

function M.command(s,car,target,cfg,now,context)
    context=context or {};s.phase=s.phase or "follow"
    local speed=(target.speed_mps or math.sqrt((target.vx or 0)^2+(target.vy or 0)^2))*3.6
    local _,_,distance=norm(target.x-car.x,target.y-car.y)
    s.last_distance=distance
    local contact=Geometry.gap(car,target)<=.05
    if not cfg.ram_enabled or speed>35 then phase(s,"follow",now);return Drive.command(car,target,cfg,nil,s) end
    if context.attacker==false then
        if distance>35 then
            if s.phase~="catchup" then phase(s,"catchup",now) end
            local cmd=Drive.command(car,target,cfg,nil,s);cmd.reason="catch_up"
            return cmd
        end
        phase(s,"cover",now)
        local rank=context.rank or 2;local sign=rank%2==0 and 1 or -1
        local yaw=target.yaw or 0
        local goal={x=target.x-math.cos(yaw)*2-math.sin(yaw)*sign*((car.half_width_m or 1)+(target.half_width_m or 1)+.8),
            y=target.y-math.sin(yaw)*2+math.cos(yaw)*sign*((car.half_width_m or 1)+(target.half_width_m or 1)+.8),vx=target.vx,vy=target.vy,lead_limit_s=target.lead_limit_s}
        local _,_,gap=norm(goal.x-car.x,goal.y-car.y)
        if gap<.8 then return brake("cover_hold") end
        local cmd=Drive.command(car,goal,cfg,nil,s)
        if gap<4 then cmd.throttle=math.min(cmd.throttle,.45) end
        return cmd
    end
    if s.phase=="cover" or s.phase=="catchup" then phase(s,"follow",now) end
    local slow=speed<=30 or s.phase~="follow"
    if s.phase=="follow" or s.phase=="ram" then
        if slow and contact then
            s.contact_at=s.contact_at or now
            s.contact_min=math.min(s.contact_min or distance,distance)
            s.contact_last=now
        elseif s.contact_last and now-s.contact_last>1.2 then
            s.contact_at=nil;s.contact_min=nil;s.contact_last=nil
        end
        local nx,ny=norm(car.x-target.x,car.y-target.y)
        local separating=((car.vx or 0)-(target.vx or 0))*nx+((car.vy or 0)-(target.vy or 0))*ny
        local outward=(car.vx or 0)*nx+(car.vy or 0)*ny
        -- A small distance increase is suspension/contact jitter, not a completed hit.
        -- Require close body contact followed by a measurable rebound or pass.
        if slow and s.contact_at and now-s.contact_at>=.15 and distance>s.contact_min+.6 and separating>.5 and outward>.5 then
            s.away_x,s.away_y=norm(car.x-target.x,car.y-target.y)
            phase(s,"backoff",now)
        end
        if s.phase~="backoff" and slow and contact and ((car.speed_mps or 0)<1.5 or math.abs(separating)<1.5) then
            s.contact_since=s.contact_since or now
            if now-s.contact_since>=.5/(cfg.aggression or 1) then
                s.away_x,s.away_y=norm(car.x-target.x,car.y-target.y)
                phase(s,"backoff",now)
            end
        else s.contact_since=nil end
        if s.phase=="ram" and now-s.since>8 then
            if contact then s.away_x,s.away_y=norm(car.x-target.x,car.y-target.y);phase(s,"backoff",now)
            else phase(s,"follow",now) end
        end
    end
    if s.phase=="backoff" then
        local ax,ay=s.away_x,s.away_y
        local facing=math.cos(car.yaw)*ax+math.sin(car.yaw)*ay
        s.backoff_direction=s.backoff_direction or (facing<0 and -1 or 1)
        local direction=s.backoff_direction
        s.backoff_x=s.backoff_x or car.x;s.backoff_y=s.backoff_y or car.y
        local progress=(car.x-s.backoff_x)*ax+(car.y-s.backoff_y)*ay
        if not s.backoff_moving and progress>.3 then s.backoff_moving=now end
        if Geometry.gap(car,target)>=math.max(3,cfg.ram_retreat_m/(cfg.aggression or 1)) or
            (s.backoff_moving and now-s.backoff_moving>7) then
            phase(s,"settle",now);return brake("ram_settle")
        end
        if not s.backoff_moving and now-s.since>10 then
            phase(s,"follow",now);return brake("ram_backoff_no_motion")
        end
        local heading=math.atan(ay,ax)-car.yaw-(direction<0 and math.pi or 0)
        heading=(heading+math.pi)%(2*math.pi)-math.pi
        local steer=clamp(heading/cfg.steer_full_angle_rad,-1,1)*direction
        local forward=car.forward_mps or ((car.vx or 0)*math.cos(car.yaw)+(car.vy or 0)*math.sin(car.yaw))
        local error=cfg.ram_reverse_kmh/3.6-forward*direction
        return {steering=steer,throttle=direction*clamp(error/3,0,.7),brake=clamp(-error/3,0,1),direction=direction,reason="ram_backoff"}
    elseif s.phase=="settle" then
        if (car.speed_mps or 0)<.8 then
            local heading=(math.atan(target.y-car.y,target.x-car.x)-car.yaw+math.pi)%(2*math.pi)-math.pi
            phase(s,math.abs(heading)>.8 and "align" or "ram",now)
        else return brake("ram_settle") end
    end
    if s.phase=="align" then
        local heading=(math.atan(target.y-car.y,target.x-car.x)-car.yaw+math.pi)%(2*math.pi)-math.pi
        if math.abs(heading)<.65 then phase(s,"settle",now);return brake("ram_settle") end
        if now-s.since>7 then phase(s,"follow",now);return brake("align_timeout") end
        return {steering=heading>0 and -.8 or .8,throttle=(car.speed_mps or 0)<3 and -.4 or 0,
            brake=(car.speed_mps or 0)>3.5 and .5 or 0,direction=-1,reason="ram_align"}
    end
    if s.phase=="ram" then
        local tuning={};for k,v in pairs(cfg) do tuning[k]=v end
        tuning.cruise_kmh=cfg.ram_speed_kmh
        local cmd=Drive.command(car,target,tuning,nil,s);cmd.reason="ram_attack";cmd.ramming=true;return cmd
    end
    return Drive.command(car,target,cfg,nil,s)
end
return M
