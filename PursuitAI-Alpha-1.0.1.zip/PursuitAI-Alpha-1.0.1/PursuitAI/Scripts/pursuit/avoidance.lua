-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local Geometry=require("pursuit.geometry")
local Recovery=require("pursuit.recovery")
local Traffic=require("pursuit.traffic")
local M={}
local function stopped(cmd,reason)
    cmd.throttle=0;cmd.brake=1;cmd.reason=reason;return cmd
end
function M.command(car,others,cmd,sensors,cfg,state,now)
    state=state or {};now=now or 0
    if not sensors or not sensors.valid then return stopped(cmd,"sensors_unavailable") end
    if sensors.front<1.8 and sensors.rear<2 then state.no_exit_since=state.no_exit_since or now
    else state.no_exit_since=nil end
    if cmd.traffic_wait or cmd.traffic_escape then
        state.recovery=nil;state.stuck_since=nil;state.blocked_since=nil;state.drive_reverse=nil
        if cmd.traffic_wait then return stopped(cmd,"traffic_wait") end
    end
    local last=not cmd.traffic_escape and state.last_command
    if last and math.abs(last.throttle)>.25 and (car.speed_mps or 0)<.4 and not state.recovery then
        state.stuck_since=state.stuck_since or now
    elseif not state.recovery then state.stuck_since=nil end
    if state.stuck_since and now-state.stuck_since>2.5 then
        Recovery.begin(state,car,sensors,now,"stuck_recover",sensors.left>sensors.right and .55 or -.55)
    end
    local recovering=Recovery.step(state,car,sensors,now)
    if recovering then
        cmd=recovering
        if cmd.throttle==0 and cmd.brake==1 then return cmd end
    end
    local direction=cmd.direction or (cmd.throttle<0 and -1 or 1)
    local fx,fy=math.cos(car.yaw)*direction,math.sin(car.yaw)*direction
    for _,other in ipairs(others or {}) do
        if other.key~=car.key then
            local ax,ay=Geometry.center(car);local bx,by=Geometry.center(other)
            local dx,dy=bx-ax,by-ay
            local forward=dx*fx+dy*fy;local lateral=-dx*fy+dy*fx
            local margin=cmd.ramming and .1 or .25
            local car_width=car.half_width_m or (car.width_m or 2)/2
            local lane=car_width+Geometry.support(other,-fy,fx)+margin
            local gap=forward-Geometry.support(car,fx,fy)-Geometry.support(other,fx,fy)
            local closing=math.max(0,((car.vx or 0)-(other.vx or 0))*fx+((car.vy or 0)-(other.vy or 0))*fy)
            local buffer=margin+closing*.15+closing*closing/16
            local predicted=Geometry.future_contact(car,other,.7,margin)
            local separating=cmd.traffic_escape and cmd.traffic_members[other.key] and
                Traffic.path_clear(car,other,direction,cmd.steering,math.min(cmd.escape_remaining or math.huge,math.max(1,car.speed_mps*.5+1)))
            if not separating and forward>0 and ((math.abs(lateral)<lane and gap<buffer) or predicted) then
                local lower=(car.priority and other.priority) and car.priority>other.priority or (not car.priority and car.key>other.key)
                if lower and (car.speed_mps or 0)<.7 and (other.speed_mps or 0)<.7 then
                    Recovery.begin(state,car,sensors,now,"cop_give_space",lateral>0 and -.5 or .5)
                end
                return stopped(cmd,"yield_to_cop")
            end
        end
    end
    local path=direction<0 and sensors.rear or sensors.front
    if (not sensors.planned_direction or sensors.planned_direction==direction) and (not sensors.planned_steering or math.abs(sensors.planned_steering-(cmd.steering or 0))<.25) then path=math.min(path,sensors.planned or math.huge) end
    local stop=.5+(car.speed_mps or 0)*.25+(car.speed_mps or 0)^2/12
    -- A wall beyond the intended impact must not redirect the final approach.
    -- Walls before the target and other police still use their normal checks.
    if cmd.ram_committed and direction>0 and cmd.ram_contact_distance and path>cmd.ram_contact_distance+1 then path=math.huge end
    if path<stop or (direction>0 and sensors.front<1.8 and car.speed_mps<1.2) then
        if direction<0 then return stopped(cmd,"rear_obstacle") end
        local side,clear=Geometry.clear_side(sensors.left,sensors.right,cmd.steering)
        if clear<stop+2 or sensors.front<1.8 then
            state.blocked_since=state.blocked_since or now
            if (car.speed_mps or 0)<.5 and now-state.blocked_since>=.6 then
                Recovery.begin(state,car,sensors,now,"wall_recover",side*-.55)
            end
            return stopped(cmd,"wall_stop")
        end
        cmd.steering=side*.8;cmd.throttle=math.min(cmd.throttle,.35);cmd.brake=math.max(cmd.brake,.25);cmd.reason="wall_turn"
    elseif direction>0 and path<stop+6 then
        state.blocked_since=nil
        local clear=math.max(sensors.left,sensors.right)
        if clear>path+2 then cmd.steering=Geometry.clear_side(sensors.left,sensors.right,cmd.steering)*.7;cmd.throttle=math.min(cmd.throttle,.45);cmd.reason="wall_avoid" end
    end
    return cmd
end
return M
