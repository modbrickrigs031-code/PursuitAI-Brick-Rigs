-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local M={}
-- Retirement is separate from physical damage. Transient jumps and planned waits
-- do not count; lack of progress must also survive repeated recovery attempts.
function M.update(s,car,tactic,cfg,now)
    if cfg.immobilized_cleanup==false then return nil end
    if (car.up_z or 1)<.2 and car.speed_mps<2 then
        s.overturned_at=s.overturned_at or now
        if now-s.overturned_at>=cfg.overturned_after_s then return "overturned" end
    else s.overturned_at=nil end
    if not s.anchor_x or (car.x-s.anchor_x)^2+(car.y-s.anchor_y)^2>25 then
        s.anchor_x=car.x;s.anchor_y=car.y;s.progress_at=now
        s.attempts=tactic.recover_attempts or 0
    end
    local command=tactic.last_command or {}
    if command.reason=="cover_hold" or command.reason=="traffic_wait" then
        s.progress_at=now;s.attempts=tactic.recover_attempts or 0
    end
    if now-(s.progress_at or now)>=cfg.stuck_after_s and
        ((tactic.recover_attempts or 0)-(s.attempts or 0)>=3 or
        (tactic.no_exit_since and now-tactic.no_exit_since>=cfg.stuck_after_s)) then return "trapped_after_recovery" end
end
return M
