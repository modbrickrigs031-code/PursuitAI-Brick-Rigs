-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local M = {}
local function distance(a,b)
    return math.sqrt((a.x-b.x)^2+(a.y-b.y)^2+(a.z-b.z)^2)
end

-- Visibility must describe the complete spawn volume and all racer viewpoints.
-- Missing checks fail closed. Existing-vehicle clearance is required in either role.
function M.allowed(candidate, player, role, cfg)
    if candidate.grounded ~= true or candidate.collision_free ~= true then return false, "unsafe_geometry" end
    if type(candidate.radius_m) ~= "number" or candidate.radius_m <= 0 then return false, "unknown_bounds" end
    if distance(candidate,player) < cfg.min_distance_m+candidate.radius_m+(player.radius_m or 0) then
        return false, "too_close"
    end
    if distance(candidate,player) > cfg.max_distance_m then return false, "too_far" end
    if role ~= "police" and candidate.hidden_from_all_racers ~= true then return false, "visible_or_unknown" end
    return true
end

return M
