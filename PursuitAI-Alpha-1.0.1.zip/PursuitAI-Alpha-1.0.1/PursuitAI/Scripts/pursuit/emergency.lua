-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local M={}
local Actions=require('pursuit.actions')
local function action(a,item,axis,wanted,label)
    if axis==nil then return end
    if item.seat:GetInputAction(axis)~=wanted then
        -- X and hold-X are independent action channels. Setting the desired
        -- state avoids two calls to Action_Beacon toggling the same channel off.
        item.seat:SetInputActionForced(axis,wanted,true)
        assert(item.seat:GetInputAction(axis)==wanted,'Emergency channel did not accept '..label)
        if a.trace then a.trace('emergency:channel_set:'..label..'='..tostring(wanted)) end
    end
end
local function siren(a,item,r,wanted)
    local count=item.seat:GetNumSirens()
    assert(type(count)=='number' and count>=0 and count<=32,'Invalid siren count')
    for _=1,count+1 do
        if item.seat:GetActiveSirenIndex()==wanted then return end
        r.input:Action_CycleSiren(Actions.params(a.action_mode,false))
    end
end
function M.restore(a,item,r)
    if not r.emergency or not a.valid(r.input) then return end
    local saved=r.emergency
    siren(a,item,r,saved.index)
    action(a,item,a.axes.Beacon,saved.beacon,'Beacon')
    action(a,item,a.axes.WarningLight,saved.warning,'WarningLight')
    action(a,item,a.axes.DisableSteering,saved.auxiliary,'DisableSteering')
    r.emergency=nil;r.emergency_at=nil
end
function M.update(a,item,r,on,now,beacons_on)
    if beacons_on==nil then beacons_on=on end
    if not on and not beacons_on then M.restore(a,item,r);return end
    if now<(r.emergency_at or 0) then return end
    r.emergency_at=now+.25
    local seat=item.seat
    if not r.emergency then
        r.emergency={index=seat:GetActiveSirenIndex(),beacon=seat:GetInputAction(a.axes.Beacon),
            warning=a.axes.WarningLight and seat:GetInputAction(a.axes.WarningLight) or false,
            auxiliary=a.axes.DisableSteering and seat:GetInputAction(a.axes.DisableSteering) or false}
    end
    action(a,item,a.axes.Beacon,beacons_on or r.emergency.beacon,'Beacon')
    action(a,item,a.axes.WarningLight,beacons_on or r.emergency.warning,'WarningLight')
    -- MR.HOGE's light bars use DisableSteering (screenshot/vehicle binding).
    -- AI steering uses SetInputAxisForced and bypasses normal key steering suppression.
    action(a,item,a.axes.DisableSteering,beacons_on or r.emergency.auxiliary,'DisableSteering')
    if on then
        local count=seat:GetNumSirens()
        assert(type(count)=='number' and count>=0 and count<=32,'Invalid siren count')
        if count>0 and seat:GetActiveSirenIndex()<0 then r.input:Action_CycleSiren(Actions.params(a.action_mode,false)) end
    else siren(a,item,r,r.emergency.index) end
end
return M
