-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local L=require('pursuit.i18n').text
-- Reflected calls only. No game offsets, memory writes, or native hooks.
-- APIs are candidates confirmed in public headers and the local executable's name strings.
-- Name presence is NOT proof that a function is compatible: probe + version gate precede use.
local M = {}; M.__index = M
local Gearbox=require("pursuit.gearbox")
local Geometry=require("pursuit.geometry")
local BodyFrame=require("pursuit.body_frame")
local Emergency=require("pursuit.emergency")
local Actions=require("pursuit.actions")
local Network=require("pursuit.network")
local system_library,engine_is_valid
local function valid(obj)
    if obj == nil then return false end
    local ok,value=pcall(function() return obj:IsValid() end)
    if not ok or value~=true then return false end
    -- UE4SS's pointer wrapper may remain valid until GC after Unreal deleted an actor.
    if system_library and engine_is_valid then
        -- Call UFunction explicitly: the wrapper's own IsValid method shadows the engine function.
        local engine_ok,engine_valid=pcall(function() return engine_is_valid(system_library,obj) end)
        return engine_ok and engine_valid==true
    end
    return true
end
local function find(path)
    local ok,obj=pcall(StaticFindObject,path)
    if ok and valid(obj) then return obj end
    return nil
end
local function string_value(value)
    if type(value)=="string" then return value end
    local ok,s=pcall(function() return value:ToString() end)
    return ok and s or "unknown"
end

M.required={
    "/Script/BrickRigs.BrickStatics:GetProjectVersion",
    "/Script/BrickRigs.BrickPlayerController:GetPlayerVehicle",
    "/Script/BrickRigs.BrickPlayerController:GetPlayerCharacter",
    "/Script/BrickRigs.BrickCharacter:GetVehicleSeat",
    "/Script/BrickRigs.Brick:GetVehicle",
    "/Script/BrickRigs.BrickVehicle:GetDriverSeat",
    "/Script/BrickRigs.BrickVehicle:GetDriverCharacter",
    "/Script/BrickRigs.BrickVehicle:IsVehicleConstructed",
    "/Script/BrickRigs.BrickVehicle:ScrapVehicle",
    "/Script/BrickRigs.SeatBrick:SetInputAxisForced",
    "/Script/BrickRigs.SeatBrick:SetInputActionForced",
    "/Script/BrickRigs.VehicleInputComponent:Action_Beacon",
    "/Script/BrickRigs.BrickEditorObject:GetWorldLocation",
    "/Script/BrickRigs.BrickEditorObject:GetWorldRotation",
    "/Script/BrickRigs.BrickEditorObject:GetRootComponent",
    "/Script/Engine.PrimitiveComponent:GetPhysicsLinearVelocityAtPoint",
    "/Script/BrickRigs.SeatBrick:GetInputAction",
    "/Script/BrickRigs.BrickPlayerController:SpawnDummy",
    "/Script/Engine.Actor:K2_DestroyActor",
    "/Script/BrickRigs.BrickCharacter:EnterVehicle",
    "/Script/Engine.Pawn:IsPlayerControlled",
    "/Script/BrickRigs.BrickEditorObject:GetEditorObjectID",
    "/Script/BrickRigs.SeatBrick:GetMainMotor",
    "/Script/BrickRigs.Brick:IsBrickBurnt",
    "/Script/Engine.KismetSystemLibrary:IsStandalone",
    "/Script/Engine.GameplayStatics:GetTimeSeconds",
    "/Script/BrickRigs.BrickVehicle:GetVehicleDisplayName",
    "/Script/BrickRigs.BrickVehicle:GetNumPassengers",
    "/Script/Engine.Controller:IsLocalController",
    "/Script/Engine.Actor:K2_GetActorLocation",
    "/Script/Engine.Actor:GetActorForwardVector",
    "/Script/Engine.Actor:GetVelocity",
    "/Script/Engine.KismetSystemLibrary:IsValid"
    ,"/Script/Engine.KismetSystemLibrary:BoxTraceSingleByProfile"
    ,"/Script/Engine.Actor:GetActorBounds"
    ,"/Script/Engine.Actor:GetActorRightVector"
    ,"/Script/Engine.Actor:K2_GetActorRotation"
    ,"/Script/BrickRigs.SeatBrick:GetNumSirens"
    ,"/Script/BrickRigs.SeatBrick:GetActiveSirenIndex"
    ,"/Script/BrickRigs.VehicleInputComponent:Action_CycleSiren"
    ,"/Script/BrickRigs.SeatBrick:GetGearRange"
    ,"/Script/BrickRigs.SeatBrick:GetCurrentGear"
    ,"/Script/BrickRigs.SeatBrick:GetCurrentRPM"
    ,"/Script/BrickRigs.SeatBrick:GetMaxRPM"
    ,"/Script/BrickRigs.SeatBrick:GetIdealRPMRange"
    ,"/Script/BrickRigs.VehicleInputComponent:Action_ShiftUp"
    ,"/Script/BrickRigs.VehicleInputComponent:Action_ShiftDown"
    ,"/Script/Engine.Actor:K2_DestroyComponent"
    ,"/Script/BrickRigs.BaseCharacter:IsAlive"
    ,"/Script/BrickRigs.BrickVehicle:ConstructVehicle"
    ,"/Script/Engine.KismetSystemLibrary:LineTraceSingleByProfile"
    ,"/Script/Engine.KismetSystemLibrary:GetProjectSavedDirectory"
    ,"/Script/Engine.GameplayStatics:GetPlayerCameraManager"
}

function M.new(cfg, log, trace)
    return setmetatable({cfg=cfg,log=log,trace=trace or function() end,vehicles={},controlled={},axes={},ready=false,drivers={},target_self=true},M)
end
function M:string(value) return string_value(value) end
function M:can_host() return Network.is_host(self) end
function M:assert_vehicle_authority(vehicle) return Network.assert_vehicle(self,vehicle) end
function M:players() return Network.players(self) end
function M:select_player(key)
    assert(not self.multiplayer or self:can_host(),'Выбор цели доступен только хосту')
    if key=='__self' then self.selected_player=nil;self.target_self=true;return end
    for _,row in ipairs(self:players()) do
        if row.key==key then self.selected_player=row;self.target_self=false;return row end
    end
    error('Игрок уже отключился. Обнови список игроков.')
end
function M:target_connected()
    return not self.selected_player or Network.connected(self,self.selected_player)
end

function M:controller()
    if not engine_is_valid then
        local ok,system,fn=pcall(function() return StaticFindObject("/Script/Engine.Default__KismetSystemLibrary"),StaticFindObject("/Script/Engine.KismetSystemLibrary:IsValid") end)
        if ok and system and fn and system:IsValid() and fn:IsValid() then system_library=system;engine_is_valid=fn end
    end
    -- A world scan traverses every Unreal object with this loader's safe settings.
    -- Keep the local controller, but check pending-kill before every use/map change.
    if valid(self.local_controller) then return self.local_controller end
    local wall=os.clock()
    assert(not self.controller_retry or wall>=self.controller_retry,"Load a map with one local player")
    self.controller_retry=wall+.5
    local matches={}
    for _,pc in ipairs(FindAllOf("BrickPlayerController") or {}) do
        if valid(pc) and pc:IsLocalController() then matches[#matches+1]=pc end
    end
    assert(#matches==1,"Load a map with one local player")
    self.local_controller=matches[1];self.controller_retry=nil
    return self.local_controller
end

function M:probe()
    self.ready=false
    local report={"PursuitAI Alpha 1.0.1", "Target game: "..self.cfg.target_version}
    local missing=0
    for _,path in ipairs(M.required) do
        local exists=find(path)~=nil
        report[#report+1]=(exists and "OK " or "MISSING ")..path
        if not exists then missing=missing+1 end
    end
    local statics=find("/Script/BrickRigs.Default__BrickStatics")
    local system=find("/Script/Engine.Default__KismetSystemLibrary")
    system_library=system
    engine_is_valid=find("/Script/Engine.KismetSystemLibrary:IsValid")
    local gameplay=find("/Script/Engine.Default__GameplayStatics")
    local enum=find("/Script/BrickRigs.EVehicleInputAxis")
    local version="unknown"
    if statics and find(M.required[1]) then
        local ok,value=pcall(function() return statics:GetProjectVersion() end)
        if ok then version=string_value(value) end
    end
    if enum then
        local ok=pcall(function()
            enum:ForEachName(function(name,value)
                local short=string_value(name):match("([^:]+)$")
                self.axes[short]=value
            end)
        end)
        if not ok then self.axes={} end
    end
    local pc_ok,pc=pcall(function() return self:controller() end)
    local standalone=false
    if system and pc_ok then
        local ok,value=pcall(function() return system:IsStandalone(pc) end)
        standalone=ok and value==true
    end
    report[#report+1]="Reported game version: "..version
    report[#report+1]="Standalone: "..tostring(standalone)
    self.multiplayer=not standalone
    self.action_mode=Actions.real_mode(find('/Script/BrickRigs.EBrActionMode'),string_value)
    self.manual_mode=nil;self.automatic_mode=nil;self.user_settings=nil
    local transmission_enum=find('/Script/BrickRigs.ETransmissionMode')
    local settings_default=find('/Script/BrickRigs.Default__BrickUserSettings')
    if transmission_enum and settings_default and find('/Script/BrickRigs.BrickUserSettings:GetUserSettings') then
        pcall(function()
            transmission_enum:ForEachName(function(name,value)
                local short=string_value(name):match('([^:]+)$')
                if short=='Manual' then self.manual_mode=value elseif short=='Automatic' then self.automatic_mode=value end
            end)
            self.user_settings=settings_default:GetUserSettings()
        end)
    end
    local transmission_ready=valid(self.user_settings) and self.manual_mode~=nil and self.automatic_mode~=nil
    report[#report+1]='Transmission settings available: '..tostring(transmission_ready)
    local host=pc_ok and self:can_host()
    local network_api=standalone or (find('/Script/Engine.Actor:HasAuthority') and find('/Script/Engine.PlayerState:GetPlayerName'))
    self.reinforcements_ready=standalone or (host and find('/Script/Engine.Actor:SetOwner')~=nil and
        find('/Script/Engine.Actor:SetReplicates')~=nil and find('/Script/Engine.Actor:ForceNetUpdate')~=nil and
        find('/Script/Engine.Controller:GetControlRotation')~=nil)
    report[#report+1]='Host authority: '..tostring(host)..'; EBrActionMode::Real='..tostring(self.action_mode)
    report[#report+1]="Axes from runtime enum: Steering="..tostring(self.axes.Steering)
        .." Throttle="..tostring(self.axes.Throttle).." Brake="..tostring(self.axes.Brake)
        .." HandBrake="..tostring(self.axes.HandBrake).." Beacon="..tostring(self.axes.Beacon)
    -- No substring/nearest-version fallback. Unknown or a different version stays diagnostic-only.
    self.ready=missing==0 and version==self.cfg.target_version and host and network_api~=nil and gameplay~=nil and self.action_mode~=nil and transmission_ready
        and self.axes.Steering~=nil and self.axes.Throttle~=nil and self.axes.Brake~=nil
        and self.axes.HandBrake~=nil and self.axes.Beacon~=nil and self.axes.WarningLight~=nil
    self.gameplay=gameplay;self.version=version
    report[#report+1]="Automatic compatibility gate: "..tostring(self.ready)
    report[#report+1]="Automatic reinforcement: null-controller construction; finite reserve; hidden safe positions"
    report[#report+1]="Collision probes: box sweeps front/left/right/rear; no global navigation"
    return table.concat(report,"\n").."\n",self.ready
end

function M:now()
    assert(self.gameplay,"Run diagnostics first")
    return self.gameplay:GetTimeSeconds(self:controller())
end

function M:key(vehicle) return vehicle:GetFullName() end

function M:current_vehicle()
    local vehicle=self:controller():GetPlayerVehicle()
    assert(valid(vehicle) and vehicle:IsVehicleConstructed(),"Enter a constructed vehicle first")
    return vehicle
end

function M:target_vehicle()
    local pc=self:controller()
    if self.multiplayer then assert(self:can_host(),L('Запуск погони доступен только хосту')) end
    if self.selected_player then
        assert(Network.connected(self,self.selected_player),L('Выбранный игрок отключился'))
        pc=self.selected_player.controller
    elseif self.multiplayer and not self.target_self then error(L('Выбери игрока-цель в меню F8')) end
    local character=pc:GetPlayerCharacter()
    assert(valid(character),"Player character unavailable")
    local seat=character:GetVehicleSeat()
    assert(valid(seat),"Player is outside a vehicle")
    local vehicle=seat:GetVehicle()
    assert(valid(vehicle) and vehicle:IsVehicleConstructed(),"Player vehicle unavailable")
    return vehicle,seat
end

function M:register_current(model_id,selected_vehicle)
    assert(self.ready,"Diagnostics must pass before vehicle registration")
    local vehicle=selected_vehicle or self:current_vehicle()
    assert(valid(vehicle),"Selected vehicle was removed")
    self:assert_vehicle_authority(vehicle)
    self.trace("register:driver_seat:before")
    local seat=vehicle:GetDriverSeat()
    self.trace("register:driver_seat:after")
    assert(valid(seat),"Vehicle has no usable driver seat")
    local key=self:key(vehicle)
    self.trace("register:main_motor:before")
    local motor=seat:GetMainMotor()
    self.trace("register:main_motor:after")
    assert(valid(motor),"Vehicle has no main motor")
    self.vehicles[key]={actor=vehicle,model_id=model_id,seat=seat,motor=motor}
    return {key=key,model_id=model_id,owned=false}
end

function M:occupied(vehicle)
    if not valid(vehicle) then return false end
    local driver=vehicle:GetDriverCharacter()
    local own_driver=0
    if valid(driver) then
        local record=self.drivers[self:key(vehicle)]
        if driver:IsPlayerControlled() or not record or not valid(record.actor)
            or self:key(driver)~=self:key(record.actor) then return true end
        own_driver=1
    end
    -- Brick Rigs counts the seated driver in GetNumPassengers as well.
    return vehicle:GetNumPassengers()>own_driver
end

function M:prepare_driver(key)
    assert(self.ready,"Driving capability unavailable")
    local item=self.vehicles[key]
    assert(item and valid(item.actor) and valid(item.seat),"Registered vehicle unavailable")
    self:assert_vehicle_authority(item.actor)
    assert(not self:occupied(item.actor),"Police car has another occupant")
    if self.drivers[key] then
        local record=self.drivers[key]
        assert(valid(record.actor),"Previous driver unavailable; reset first")
        assert(record.actor:IsAlive() and not record.actor:IsPlayerControlled(),"Service driver is not available for reseating")
        local seated=item.actor:GetDriverCharacter()
        if not valid(seated) then
            record.actor:EnterVehicle(item.actor,item.seat:GetEditorObjectID())
            seated=item.actor:GetDriverCharacter()
            assert(valid(seated) and self:key(seated)==self:key(record.actor),"Could not reseat owned driver")
            assert(valid(record.input),"Service input was removed")
            record.input.VehicleSeat=item.seat;record.range=nil;record.scan=nil
            self.trace("driver:reseated:"..key)
        end
        return
    end
    local before={}
    for _,char in ipairs(FindAllOf("BrickCharacter") or {}) do if valid(char) then before[self:key(char)]=true end end
    local handbrake=item.seat:GetInputAction(self.axes.HandBrake)
    assert(type(handbrake)=="boolean","Handbrake state unavailable")
    local p=item.actor:K2_GetActorLocation()
    local pc=self:controller()
    self.trace("driver:spawn:before")
    pc:SpawnDummy({X=p.X,Y=p.Y,Z=p.Z+200},0)
    local created={}
    for _,char in ipairs(FindAllOf("BrickCharacter") or {}) do
        if valid(char) and not before[self:key(char)] then created[#created+1]=char end
    end
    assert(#created==1,"Could not identify a single driver created by this action")
    local driver=created[1]
    assert(not driver:IsPlayerControlled(),"Spawn result is player-controlled; not claiming it")
    self.drivers[key]={actor=driver,controller=pc,handbrake=handbrake}
    self.controlled[key]=true -- Include prepared drivers in rollback even before the first input.
    local ok,err=pcall(function()
        assert(not self:occupied(item.actor),"Someone entered the police car during preparation")
        driver:EnterVehicle(item.actor,item.seat:GetEditorObjectID())
        local seated=item.actor:GetDriverCharacter()
        assert(valid(seated) and self:key(seated)==self:key(driver),"Driver could not enter selected seat")
        -- Direct action service, as used by the user-tested alpha.14. Registering
        -- VehicleInputComponent for normal engine ticking caused a native crash
        -- after start in alpha.15; it must not be attached as a ticking component.
        local component=StaticConstructObject(find("/Script/BrickRigs.VehicleInputComponent"),item.actor)
        assert(valid(component),"Could not create police gearbox input")
        self.drivers[key].input=component
        component.VehicleSeat=item.seat
        self.trace('input:direct_actions:'..key)
        self.trace("driver:seated")
    end)
    if not ok then self:release(key);error(err) end
end

function M:snapshot(vehicle,occupied_seat)
    assert(valid(vehicle),"Vehicle was removed")
    local seat=occupied_seat or vehicle:GetDriverSeat()
    assert(valid(seat),"Vehicle has no live driver seat")
    local p=seat:GetWorldLocation();local rotation=seat:GetWorldRotation()
    local component=seat:GetRootComponent()
    assert(valid(component),"Driver body was removed")
    local v=component:GetPhysicsLinearVelocityAtPoint(p,FName("None"))
    local origin,extent={},{};vehicle:GetActorBounds(true,origin,extent,false)
    self.body_frames=self.body_frames or {}
    return BodyFrame.sample(self.body_frames,self:key(vehicle),seat:GetFullName(),p,rotation,v,
        vehicle:K2_GetActorRotation(),origin,extent)
end

function M:sensors(key,car,target,command,now)
    local item=self.vehicles[key];local record=self.drivers[key]
    now=now or self:now()
    local allow_target_contact=not command or command.allow_target_contact~=false
    if record.scan and now-record.scan_at<.2 and record.allow_target_contact==allow_target_contact
        and math.abs((record.scan.planned_steering or 0)-(command and command.steering or 0))<.25
        and record.scan.planned_direction==(command and (command.direction or (command.throttle<0 and -1 or 1)) or 1) then return record.scan end
    local ignore={item.actor,record.actor}
    if allow_target_contact then
        ignore[#ignore+1]=target
        local target_driver=target:GetDriverCharacter();if valid(target_driver) then ignore[#ignore+1]=target_driver end
    end
    -- Registered active cops use the tighter oriented body checks below in avoidance.
    -- Do not also block them with the wider world-geometry sensor envelope.
    for other_key,other_driver in pairs(self.drivers) do
        if other_key~=key and self.controlled[other_key] then
            local other=self.vehicles[other_key]
            if other and valid(other.actor) then ignore[#ignore+1]=other.actor end
            if valid(other_driver.actor) then ignore[#ignore+1]=other_driver.actor end
        end
    end
    record.allow_target_contact=allow_target_contact
    local span=math.max(25,math.min(500,15+car.speed_mps*.4+car.speed_mps^2/10))
    local library=system_library
    local color={R=0,G=0,B=0,A=0}
    local low=car.low_center
    if low then
        low={X=low.X,Y=low.Y,Z=low.Z}
        local ground={}
        local ok=self.cfg and library:LineTraceSingleByProfile(item.actor,car.center,
            {X=car.center.X,Y=car.center.Y,Z=car.center.Z-350},FName("Vehicle"),true,ignore,0,ground,true,color,color,0)
        if ok and ground.ImpactNormal and ground.ImpactNormal.Z>.7 then low.Z=ground.ImpactPoint.Z+35 end
    end
    local function level_sweep(angle,start)
        start=start or car.center
        -- Horizontal world frame: body pitch/roll cannot aim a wall probe into soil.
        local heading=car.yaw+angle
        local dx,dy,dz=math.cos(heading),math.sin(heading),0
        local finish={X=start.X+dx*span*100,Y=start.Y+dy*span*100,Z=start.Z+dz*span*100}
        local orientation={Pitch=0,Yaw=math.deg(heading),Roll=0}
        local hit={}
        local half={X=25,Y=math.max(50,math.min(160,(car.half_width_m or 1)*85)),Z=20}
        local blocked
        for attempt=1,3 do
            hit={}
            blocked=library:BoxTraceSingleByProfile(item.actor,start,finish,half,
                orientation,FName("Vehicle"),true,ignore,0,hit,true,color,color,0)
            local n=hit.ImpactNormal
            if not blocked or not n or n.Z<.85 or attempt==3 then break end
            -- Suspension pitch can point the sensor into a perfectly flat road.
            -- Retry along the hit surface, without ignoring its actor: walls on
            -- the same landscape/mesh must still be visible in the next sweep.
            local dot=dx*n.X+dy*n.Y+dz*n.Z
            dx,dy,dz=dx-dot*n.X,dy-dot*n.Y,dz-dot*n.Z
            local magnitude=math.sqrt(dx*dx+dy*dy+dz*dz)
            if magnitude<.1 then break end
            dx,dy,dz=dx/magnitude,dy/magnitude,dz/magnitude
            finish={X=start.X+dx*span*100,Y=start.Y+dy*span*100,Z=start.Z+dz*span*100}
            orientation={Pitch=math.deg(math.atan(dz,math.sqrt(dx*dx+dy*dy))),
                Yaw=math.deg(math.atan(dy,dx)),Roll=0}
        end
        if not blocked then return math.huge end
        -- Repeated ground-plane hits are support, not a wall. Never ignore the
        -- whole terrain actor: a vertical barrier on that same actor must count.
        if hit.ImpactNormal and hit.ImpactNormal.Z>=.85 then return math.huge end
        assert(type(hit.Distance)=="number","Collision trace distance unavailable")
        local nose=Geometry.support(car,dx,dy)*100-25
        return math.max(0,(hit.Distance-nose)/100)
    end
    local function sweep(angle)
        local high=level_sweep(angle,car.center)
        return low and math.min(high,level_sweep(angle,low)) or high
    end
    local direction=command and (command.direction or (command.throttle<0 and -1 or 1)) or 1
    local planned=(direction<0 and math.pi or 0)+(command and command.steering or 0)*.65*direction
    local front,rear=sweep(0),sweep(math.pi)
    local result={valid=true,front=front,left=sweep(-.7),right=sweep(.7),side_left=sweep(-math.pi/2),side_right=sweep(math.pi/2),rear=rear,planned=math.abs(command and command.steering or 0)<.05 and (direction<0 and rear or front) or sweep(planned),planned_direction=direction,planned_steering=command and command.steering or 0}
    record.scan=result;record.scan_at=now
    return result
end

function M:transmission(key,car)
    local item=self.vehicles[key];local record=self.drivers[key]
    local low,high,ideal_min,ideal_max={},{},{},{}
    -- Refresh ranges only once per driver; the actual gear and RPM are sampled each tick.
    if not record.range then
        item.seat:GetGearRange(low,high);item.seat:GetIdealRPMRange(ideal_min,ideal_max)
        record.range={min=low.OutMin,max=high.OutMax,ideal_max=ideal_max.OutMax,ideal_min=ideal_min.OutMin}
        assert(type(record.range.min)=="number" and type(record.range.max)=="number","Gear range unavailable")
    end
    local forward_mps=car and car.forward_mps
    if forward_mps==nil then
        local velocity=item.actor:GetVelocity();local forward=item.actor:GetActorForwardVector()
        forward_mps=(velocity.X*forward.X+velocity.Y*forward.Y)/100
    end
    assert(valid(self.user_settings),'Transmission settings unavailable; run diagnostics')
    local mode=self.user_settings.TransmissionMode
    assert(mode==self.manual_mode or mode==self.automatic_mode,'Unknown transmission mode')
    return {gear=item.seat:GetCurrentGear(),rpm=item.seat:GetCurrentRPM(),max_rpm=item.seat:GetMaxRPM(),manual=mode==self.manual_mode,
        min_gear=record.range.min,max_gear=record.range.max,ideal_max=record.range.ideal_max,ideal_min=record.range.ideal_min,
        forward_mps=forward_mps}
end

function M:prediction_target(car,target,actor,now)
    local record=self.drivers[car.key]
    local distance=math.sqrt((target.x-car.x)^2+(target.y-car.y)^2)
    local lead=math.min(distance/35,self.cfg.drive.max_lead_s)
    local speed=math.sqrt((target.vx or 0)^2+(target.vy or 0)^2)
    if not record or lead*speed<1 or not target.center or not car.center then return target end
    local cache=record.prediction
    if not cache or now-cache.at>.3 or cache.actor~=self:key(actor) or
        (cache.x-target.x)^2+(cache.y-target.y)^2>4 or
        ((cache.vx or 0)-(target.vx or 0))^2+((cache.vy or 0)-(target.vy or 0))^2>16 then
        local ignore={actor,self.vehicles[car.key].actor,record.actor}
        local driver=actor:GetDriverCharacter();if valid(driver) then ignore[#ignore+1]=driver end
        for key,other in pairs(self.drivers) do
            if key~=car.key then
                local item=self.vehicles[key]
                if item and valid(item.actor) then ignore[#ignore+1]=item.actor end
                if valid(other.actor) then ignore[#ignore+1]=other.actor end
            end
        end
        local color={R=0,G=0,B=0,A=0}
        local function blocked(start,finish,width)
            local hit={}
            local yaw=math.deg(math.atan(finish.Y-start.Y,finish.X-start.X))
            local yes=system_library:BoxTraceSingleByProfile(actor,start,finish,{X=25,Y=width,Z=25},
                {Pitch=0,Yaw=yaw,Roll=0},FName('Vehicle'),true,ignore,0,hit,true,color,color,0)
            return yes and (not hit.ImpactNormal or hit.ImpactNormal.Z<.85),hit
        end
        local finish={X=target.center.X+(target.vx or 0)*lead*100,
            Y=target.center.Y+(target.vy or 0)*lead*100,Z=target.center.Z}
        local wall,hit=blocked(target.center,finish,math.max(50,(target.half_width_m or 1)*100))
        local limit=lead
        if wall then limit=math.max(0,((hit.Distance or 0)/100-1)/speed) end
        finish={X=target.center.X+(target.vx or 0)*limit*100,
            Y=target.center.Y+(target.vy or 0)*limit*100,Z=target.center.Z}
        if limit>0 and blocked(car.center,finish,math.max(50,(car.half_width_m or 1)*100)) then limit=0 end
        cache={at=now,x=target.x,y=target.y,vx=target.vx,vy=target.vy,actor=self:key(actor),limit=limit}
        record.prediction=cache
        if limit<lead and now>=(record.prediction_report_at or 0) then
            record.prediction_report_at=now+3
            self.trace(string.format('prediction:wall_limited:%s lead_s=%.2f limited_s=%.2f',car.key,lead,limit))
        end
    end
    local result={};for k,v in pairs(target) do result[k]=v end
    result.lead_limit_s=cache.limit
    return result
end

local function same_object(a,b)
    if a==b then return true end
    if not valid(a) or not valid(b) then return false end
    local ok,equal=pcall(function() return a:GetFullName()==b:GetFullName() end)
    return ok and equal
end
function M:refresh_binding(key,now)
    local item=self.vehicles[key]
    if not item or not valid(item.actor) or not item.actor:IsVehicleConstructed() then return end
    local record=self.drivers[key]
    if not record or now<(record.check_binding_at or 0) then return end
    record.check_binding_at=now+.5
    local seat=item.actor:GetDriverSeat()
    local motor=valid(seat) and seat:GetMainMotor() or nil
    -- A whole-vehicle rebuild changes both objects; ordinary damaged seats/motors
    -- still disable the car. Never claim a different actor just because it looks alike.
    if valid(seat) and valid(motor) and not same_object(seat,item.seat) and not same_object(motor,item.motor)
        and not seat:IsBrickBurnt() and not motor:IsBrickBurnt() then
        if self:occupied(item.actor) then return end
        self:release(key);item.seat=seat;item.motor=motor
        if self.body_shapes then self.body_shapes[key]=nil end
        if self.body_centers then self.body_centers[key]=nil end
        self:prepare_driver(key)
        self.trace("vehicle:binding_refreshed:"..key)
    elseif valid(item.seat) and valid(item.motor) and valid(record.actor) and record.actor:IsAlive()
        and not item.seat:IsBrickBurnt() and not item.motor:IsBrickBurnt() and not record.actor:IsPlayerControlled() then
        if not valid(item.actor:GetDriverCharacter()) and not self:occupied(item.actor) then self:prepare_driver(key) end
    end
end

function M:observe(key)
    local item=self.vehicles[key]
    if not item then return {disabled=false} end
    if not valid(item.actor) then return {disabled=true,reason="vehicle_removed"} end
    if not item.actor:IsVehicleConstructed() then return {disabled=false,pending=true,reason="reconstructing"} end
    if item.retired_reason then return {disabled=true,reason=item.retired_reason} end
    -- Missing objects previously seen as valid are positive destruction evidence.
    if not valid(item.seat) then return {disabled=true,reason="driver_seat_removed"} end
    if item.seat:IsBrickBurnt() then return {disabled=true,reason="driver_seat_burnt"} end
    if not valid(item.motor) then return {disabled=true,reason="main_motor_removed"} end
    if item.motor:IsBrickBurnt() then return {disabled=true,reason="main_motor_burnt"} end
    local driver=self.drivers[key]
    if driver and not valid(driver.actor) then return {disabled=true,reason="driver_removed"} end
    if driver and not driver.actor:IsAlive() then return {disabled=true,reason="driver_dead"} end
    return {disabled=false}
end

function M:apply(key,command,now,car)
    assert(self.ready,"Driving capability unavailable")
    local item=self.vehicles[key]
    assert(item and valid(item.actor) and valid(item.seat),"Registered police vehicle unavailable")
    self:assert_vehicle_authority(item.actor)
    assert(not self:occupied(item.actor),"A registered police vehicle is occupied; stop the pursuit")
    if not self.drivers[key] then self:prepare_driver(key) end
    local record=self.drivers[key]
    now=now or self:now()
    local telemetry=self:transmission(key,car)
    local shift,throttle,brake=Gearbox.command(record,telemetry,command,now)
    record.last_applied={gear=telemetry.gear,rpm=telemetry.rpm,throttle=throttle,brake=brake,
        direction=command.direction or (command.throttle<0 and -1 or 1)}
    if shift then
        assert(valid(record.input),"Police gearbox input removed")
        if shift>0 then record.input:Action_ShiftUp(Actions.params(self.action_mode,false))
        else record.input:Action_ShiftDown(Actions.params(self.action_mode,false)) end
    end
    self.controlled[key]=true
    local speed=car and car.speed_mps or math.abs(telemetry.forward_mps)
    record.last_applied.forward_mps=telemetry.forward_mps
    record.last_applied.requested_throttle=command.throttle
    record.last_applied.handbrake=brake>=.8 and speed<.5
    item.seat:SetInputActionForced(self.axes.HandBrake,brake>=.8 and speed<.5,true)
    local emergency_ok,emergency_error=pcall(Emergency.update,self,item,record,self.cfg.drive.sirens_enabled~=false,now,self.cfg.drive.beacons_enabled~=false)
    if not emergency_ok and not record.emergency_warning then
        record.emergency_warning=true;self.trace("emergency:unavailable:"..tostring(emergency_error))
    end
    if not record.emergency_report_at or now>=record.emergency_report_at then
        record.emergency_report_at=now+5
        pcall(function()
            self.trace("emergency:state:"..key.." beacon="..tostring(item.seat:GetInputAction(self.axes.Beacon))
                .." warning="..tostring(item.seat:GetInputAction(self.axes.WarningLight))
                .." siren="..tostring(item.seat:GetActiveSirenIndex())..' real_mode='..tostring(self.action_mode)..' input_mode=direct_actions')
        end)
    end
    item.seat:SetInputAxisForced(self.axes.Steering,command.steering,true)
    item.seat:SetInputAxisForced(self.axes.Throttle,throttle,true)
    item.seat:SetInputAxisForced(self.axes.Brake,brake,true)
end

function M:release(key)
    if not self.controlled[key] then return end
    if not self:can_host() then self.drivers[key]=nil;self.controlled[key]=nil;return end
    local item=self.vehicles[key]
    local record=self.drivers[key]
    -- Never delete or eject a character after a player takes control of it.
    local claimed=record and valid(record.actor) and record.actor:IsPlayerControlled()
    if claimed then self.drivers[key]=nil;self.controlled[key]=nil;return end
    local owned=not item or not valid(item.actor) or pcall(function() self:assert_vehicle_authority(item.actor) end)
    if item and valid(item.actor) and valid(item.seat) then
        -- Do not touch a human's seat inputs if someone entered during this tick.
        if owned and not self:occupied(item.actor) then
            pcall(Emergency.restore,self,item,record or {})
            item.seat:SetInputAxisForced(self.axes.Steering,0,true)
            item.seat:SetInputAxisForced(self.axes.Throttle,0,true)
            item.seat:SetInputAxisForced(self.axes.Brake,0,true)
            local parking=true
            if record then parking=record.handbrake end
            item.seat:SetInputActionForced(self.axes.HandBrake,parking,true)
        end
    end
    if record and valid(record.actor) then
        if valid(record.input) and item and valid(item.actor) then item.actor:K2_DestroyComponent(record.input) end
        record.actor:K2_DestroyActor()
        assert(not valid(record.actor),"Driver removal did not complete")
    end
    -- Leaving the seat may apply the default parking state; restore the original afterwards.
    if owned and record and item and valid(item.actor) and valid(item.seat) and not self:occupied(item.actor) then
        item.seat:SetInputActionForced(self.axes.HandBrake,record.handbrake,true)
    end
    self.drivers[key]=nil
    self.controlled[key]=nil
end

function M:release_all()
    local keys={};for key in pairs(self.controlled) do keys[#keys+1]=key end
    for _,key in ipairs(keys) do pcall(function() self:release(key) end) end
end

function M:retire(key,reason)
    if not self:can_host() then return false end
    local item=self.vehicles[key]
    if item and valid(item.actor) and not pcall(function() self:assert_vehicle_authority(item.actor) end) then return false end
    if not item or not valid(item.actor) or self:occupied(item.actor) then return false end
    item.retired_reason=reason;self:release(key);return true
end

function M:cleanup(key)
    if not self:can_host() then return false end
    local item=self.vehicles[key]
    if item and valid(item.actor) and not pcall(function() self:assert_vehicle_authority(item.actor) end) then return false end
    if not item then return false end
    if not valid(item.actor) then self:release(key);return true end
    if self:occupied(item.actor) then return false end
    if not self:observe(key).disabled then return false end
    self:release(key)
    self.trace("cleanup:disabled_vehicle:"..key)
    item.actor:ScrapVehicle()
    return not valid(item.actor)
end

function M:reset()
    self:release_all()
    assert(next(self.controlled)==nil,"Driver cleanup is still pending; retry Stop before reset")
    self.vehicles={};self.body_frames={}
end

M.valid=valid
return M
