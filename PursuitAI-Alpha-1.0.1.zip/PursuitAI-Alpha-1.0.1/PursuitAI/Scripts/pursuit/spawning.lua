-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local L=require('pursuit.i18n').text
local Files=require("pursuit.fleet_files")
local Drive=require('pursuit.drive')
local Avoidance=require('pursuit.avoidance')
local Stability=require('pursuit.stability')
local Departure=require('pursuit.departure')
local Network=require('pursuit.network')
local M={};M.__index=M
local color={R=0,G=0,B=0,A=0}
function M.new(adapter)
    return setmetatable({adapter=adapter,system=StaticFindObject("/Script/Engine.Default__KismetSystemLibrary")},M)
end
local function hash(path)
    local f=io.open(path,"rb");if not f then return nil end
    local data=f:read("a");f:close()
    local h=0xcbf29ce484222325
    for i=1,#data do h=(h ~ data:byte(i))*0x100000001b3 end
    return string.format("%016x",h),#data
end
function M:pool()
    local saved=self.system:GetProjectSavedDirectory():ToString():gsub("\\","/")
    local pool={};self.local_ids={}
    for id,entry in pairs(Files) do
        for _,local_id in ipairs({entry.local_id,id}) do
            local digest,bytes=hash(saved.."/Vehicles/"..local_id.."/Vehicle.brv")
            if digest==entry.fnv and bytes==entry.bytes then pool[id]=true;self.local_ids[id]=local_id;break end
        end
    end
    return pool
end
function M:camera()
    local pc=self.adapter:controller()
    local cam=self.adapter.gameplay:GetPlayerCameraManager(pc,0)
    assert(self.adapter.valid(cam),"Player camera is unavailable")
    local p,r=cam:GetCameraLocation(),cam:GetCameraRotation()
    local yaw,pitch=math.rad(r.Yaw),math.rad(r.Pitch)
    return {x=p.X/100,y=p.Y/100,z=p.Z/100,fx=math.cos(yaw)*math.cos(pitch),
        fy=math.sin(yaw)*math.cos(pitch),fz=math.sin(pitch),
        -- Circumscribed cone includes both horizontal and vertical screen edges.
        half=math.rad(math.min(89,math.max(60,cam:GetFOVAngle()*.8+15)))}
end
function M.hidden(p,cam)
    local dx,dy,dz=p.x-cam.x,p.y-cam.y,p.z+3-cam.z
    local d=math.sqrt(dx*dx+dy*dy+dz*dz)
    if d<=p.radius_m then return false end
    local angle=math.acos(math.max(-1,math.min(1,(dx*cam.fx+dy*cam.fy+dz*cam.fz)/d)))
    return angle>cam.half+math.asin(p.radius_m/d)+math.rad(5)
end
function M.hidden_from(p,cameras,min_distance)
    if not cameras or #cameras==0 then return false end
    for _,cam in ipairs(cameras) do
        if not M.hidden(p,cam) then return false end
        if (p.x-cam.x)^2+(p.y-cam.y)^2<(min_distance or 0)^2 then return false end
    end
    return true
end
local function view(position,rotation,fov)
    local yaw,pitch=math.rad(rotation.Yaw),math.rad(rotation.Pitch)
    return {x=position.X/100,y=position.Y/100,z=position.Z/100,
        fx=math.cos(yaw)*math.cos(pitch),fy=math.sin(yaw)*math.cos(pitch),fz=math.sin(pitch),
        half=math.rad(math.min(89,math.max(60,(fov or 85)*.8+15)))}
end
function M:cameras(now)
    local a=self.adapter
    if not a.multiplayer then return {self:camera()} end
    assert(a:can_host(),L('Камеры подкрепления проверяет хост'))
    if not self.viewer_rows or now>=(self.viewers_at or 0)+1 then self.viewer_rows=a:players();self.viewers_at=now end
    local cameras={}
    for _,row in ipairs(self.viewer_rows) do
        if Network.connected(a,row) then
            local pc=row.controller
            if pc:IsLocalController() then cameras[#cameras+1]=self:camera()
            else
                -- Use the server camera if available. Otherwise estimate the
                -- remote view from its character and replicated control rotation.
                local ok,camera=pcall(function()
                    local manager=pc.PlayerCameraManager
                    if a.valid(manager) then return view(manager:GetCameraLocation(),manager:GetCameraRotation(),manager:GetFOVAngle()) end
                    local character=pc:GetPlayerCharacter()
                    assert(a.valid(character),L('Удалённая камера недоступна'))
                    local position=character:K2_GetActorLocation()
                    return view({X=position.X,Y=position.Y,Z=position.Z+170},pc:GetControlRotation(),85)
                end)
                assert(ok and camera,L('Положение камеры игрока неизвестно; подкрепление отложено'))
                cameras[#cameras+1]=camera
            end
        end
    end
    assert(#cameras>0,L('Нет доступных камер игроков'))
    return cameras
end
function M:ground(x,y,z,ignore)
    local hit={}
    local yes=self.system:LineTraceSingleByProfile(self.adapter:controller(),{X=x*100,Y=y*100,Z=(z+35)*100},
        {X=x*100,Y=y*100,Z=(z-90)*100},FName("Vehicle"),true,ignore or {},0,hit,true,color,color,0)
    if yes and hit.ImpactNormal and hit.ImpactNormal.Z>.85 then return hit.ImpactPoint.Z/100 end
end
function M:clear(p,ignore)
    local hit={}
    local yes=self.system:BoxTraceSingleByProfile(self.adapter:controller(),
        {X=p.x*100,Y=p.y*100,Z=(p.z+3.5)*100},{X=p.x*100,Y=p.y*100,Z=(p.z+3.5)*100+1},
        {X=500,Y=300,Z=300},{Pitch=0,Yaw=p.yaw,Roll=0},FName("Vehicle"),true,ignore or {},0,hit,true,color,color,0)
    return not yes
end
function M:candidate(target,now)
    local cameras=self:cameras(now)
    local min_distance=self.adapter.multiplayer and self.adapter.cfg.session.spawn.min_distance_m or 0
    -- Rotate candidates between attempts, rather than probing the same blocked side forever.
    self.sequence=(self.sequence or 0)+1
    for i=1,8 do
        local angle=(i+self.sequence*.618)*math.pi/4
        local radius=180+(self.sequence%3)*40
        local x,y=target.x+math.cos(angle)*radius,target.y+math.sin(angle)*radius
        local p={x=x,y=y,z=target.z,radius_m=7,yaw=math.deg(angle+math.pi)}
        if M.hidden_from(p,cameras,min_distance) then
            local z=self:ground(x,y,target.z)
            if z then
                p.z=z
                local ca,sa=math.cos(angle),math.sin(angle);local grounded=true
                for _,corner in ipairs({{-4,-2},{-4,2},{4,-2},{4,2}}) do
                    local height=self:ground(x+ca*corner[1]-sa*corner[2],y+sa*corner[1]+ca*corner[2],z)
                    if not height or math.abs(height-z)>.5 then grounded=false;break end
                end
                if grounded and self:clear(p) then
                    p.grounded=true;p.collision_free=true;p.hidden_from_all_racers=M.hidden_from(p,cameras,min_distance)
                    return p
                end
            end
        end
    end
end
function M:begin(request,target)
    local a=self.adapter;local pc=a:controller()
    if a.multiplayer then assert(a:can_host() and a.reinforcements_ready,L('Подкрепление доступно только хосту с нужными API')) end
    local id=assert(self.local_ids[request.model_id],"Reinforcement file unavailable")
    local p=request.candidate
    local actor=pc:GetWorld():SpawnActor(target:GetClass(),{X=p.x*100,Y=p.y*100,Z=(p.z+2)*100},
        {Pitch=0,Yaw=p.yaw,Roll=0})
    assert(a.valid(actor),"Reinforcement actor creation failed")
    self.pending={actor=actor,request=request,started=a:now()}
    -- A spawning player controller would automatically move the human into this car.
    -- A null controller constructs an unoccupied vehicle, tested in 1.11.7.
    actor:ConstructVehicle({FileType=1,UGCType=1,LocalItemId=id,Title="PursuitAI "..request.model_id},nil,nil,true)
    -- Construction finishes asynchronously. Assigning SpawningPlayerState before
    -- completion makes Brick Rigs seat that player even with a null controller.
    -- Keep the server-created actor unassigned until poll sees completed bricks.
    if a.multiplayer then a.trace('reinforcement:network_created:awaiting_construction:'..request.model_id) end
end
function M:poll(target,now)
    local p=self.pending;if not p then return nil,"missing" end
    local a=self.adapter;local actor=p.actor
    if not a.valid(actor) then return nil,"removed" end
    if not actor:IsVehicleConstructed() then return nil end
    if a.multiplayer and not p.network_announced then
        Network.prepare_spawn(a,actor)
        actor:ForceNetUpdate();p.network_announced=true
        a.trace('reinforcement:network_constructed:host_owner')
    end
    if a:occupied(actor) then return nil,"occupied" end
    local position=actor:K2_GetActorLocation();local velocity=actor:GetVelocity()
    if now-p.started<1 or math.abs(velocity.Z)>100 then return nil end
    local point=p.request.candidate
    local current={x=position.X/100,y=position.Y/100,z=point.z,yaw=point.yaw,radius_m=7}
    if not p.key and (current.x-point.x)^2+(current.y-point.y)^2>16 then return nil,"spawn_displaced" end
    local distance=math.sqrt((current.x-target.x)^2+(current.y-target.y)^2)
    if distance<a.cfg.session.spawn.min_distance_m+10 or distance>a.cfg.session.spawn.max_distance_m then return nil,"target_moved" end
    local ignore={actor};local driver=p.key and a.drivers[p.key]
    if driver and a.valid(driver.actor) then ignore[#ignore+1]=driver.actor end
    local min_distance=a.multiplayer and a.cfg.session.spawn.min_distance_m or 0
    if not M.hidden_from(current,self:cameras(now),min_distance) or not self:clear(current,ignore) then return nil,"spawn_became_visible_or_blocked" end
    if not p.key then
        local item=a:register_current(p.request.model_id,actor);p.key=item.key;p.item=item
        a:prepare_driver(item.key);p.departure={};p.drive={}
        a.trace('reinforcement:departure_begin:'..p.request.model_id)
    end
    local item=p.item
    a:refresh_binding(item.key,now)
    if a:observe(item.key).disabled then return nil,"spawn_unusable" end
    local car=a:snapshot(actor)
    local ready,progress=Departure.ready(p.departure,car,target)
    if not ready then
        local aim=a:prediction_target(car,target,assert(a:target_vehicle()),now)
        local command=Drive.command(car,aim,a.cfg.drive,nil,p.drive);command.allow_target_contact=true
        command=Stability.command(p.drive,car,command,a.cfg.drive,now)
        local sensors=a:sensors(item.key,car,assert(a:target_vehicle()),command,now)
        local others={car}
        for key,record in pairs(a.drivers) do
            local other=a.vehicles[key]
            if key~=item.key and other and a.valid(other.actor) then others[#others+1]=a:snapshot(other.actor) end
        end
        command=Avoidance.command(car,others,command,sensors,a.cfg.drive,p.drive,now)
        p.drive.last_command=command;a:apply(item.key,command,now,car)
        return nil
    end
    p.departed=true
    a.trace(string.format('reinforcement:departure_confirmed:%s progress_m=%.2f speed_mps=%.2f',p.request.model_id,progress,car.speed_mps))
    item.owned=true
    return item
end
function M:discard()
    local p=self.pending;if not p then return end
    local a=self.adapter
    if a.multiplayer and not a:can_host() then self.pending=nil;return end
    if p.key then a:release(p.key) end
    if a.multiplayer and a.valid(p.actor) then
        local authorized=pcall(Network.assert_vehicle,a,p.actor)
        if not authorized then self.pending=nil;return end
    end
    if a.valid(p.actor) and not a:occupied(p.actor) then
        if p.actor:IsVehicleConstructed() then p.actor:ScrapVehicle() else p.actor:K2_DestroyActor() end
    end
    if p.key then a.vehicles[p.key]=nil end
    self.pending=nil
end
function M:accept() self.pending=nil end
return M
