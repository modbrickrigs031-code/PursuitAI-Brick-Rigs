-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local L=require('pursuit.i18n').text
-- Poll keys on the game thread; do not enter this Lua state from an input worker.
local M={};M.__index=M
function M.new(adapter,report)
    return setmetatable({adapter=adapter,report=report,bindings={},warned=false},M)
end
function M:bind(name,callback)
    self.bindings[#self.bindings+1]={name=name,key={KeyName=FName(name)},callback=callback,down=false}
end
function M:poll()
    local ok,pc=pcall(function() return self.adapter:controller() end)
    if not ok then
        for _,binding in ipairs(self.bindings) do binding.down=false end
        return
    end
    for _,binding in ipairs(self.bindings) do
        local read,down=pcall(function() return pc:IsInputKeyDown(binding.key)==true end)
        if not read then
            if not self.warned then self.warned=true;self.report(L("Горячие клавиши недоступны; используй меню F8.")) end
            return
        end
        local pressed=down and not binding.down
        binding.down=down
        if pressed then binding.callback() end
    end
end
return M
