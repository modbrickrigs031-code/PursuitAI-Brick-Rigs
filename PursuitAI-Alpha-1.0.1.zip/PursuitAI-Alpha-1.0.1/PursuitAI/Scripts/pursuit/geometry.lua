-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
local M={}
-- When both sides are equally open, preserve the intended turn instead of
-- always choosing right. Unequal clearances still favour the safer side.
function M.clear_side(left,right,steering)
    if left>right then return -1,left end
    if right>left then return 1,right end
    return (steering or 0)<0 and -1 or 1,left
end
function M.center(c,t)
    local p=c.center
    return (p and p.X/100 or c.x)+(c.vx or 0)*(t or 0), (p and p.Y/100 or c.y)+(c.vy or 0)*(t or 0)
end
function M.support(c,x,y)
    local ca,sa=math.cos(c.yaw or 0),math.sin(c.yaw or 0)
    return math.abs(ca*x+sa*y)*(c.half_length_m or c.radius_m or 2.5)+
        math.abs(-sa*x+ca*y)*(c.half_width_m or (c.width_m or 2)/2)
end
-- Separating axes give a surface gap, not a centre-to-centre exclusion circle.
function M.gap(a,b,t)
    local ax,ay=M.center(a,t);local bx,by=M.center(b,t);local dx,dy=bx-ax,by-ay
    local gap=-math.huge
    for _,yaw in ipairs({a.yaw or 0,b.yaw or 0}) do
        for _,angle in ipairs({yaw,yaw+math.pi/2}) do
            local x,y=math.cos(angle),math.sin(angle)
            gap=math.max(gap,math.abs(dx*x+dy*y)-M.support(a,x,y)-M.support(b,x,y))
        end
    end
    return gap
end
function M.future_contact(a,b,horizon,margin)
    for i=1,5 do local t=horizon*i/5;if M.gap(a,b,t)<margin then return true,t end end
    return false
end
return M
