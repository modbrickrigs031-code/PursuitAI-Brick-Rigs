-- MADE BY MR.HOGE | PursuitAI Alpha 1.0.1 | See LICENSE.txt
-- Defaults for the first manual-pursuit alpha. All performance values below are tuning defaults.
return {
    language='en',
    target_version="1.11.7",
    tick_ms=100,
    session={
        reserve=6,reinforcements_enabled=false,
        reinforcement_delay_s=8,
        overturned_after_s=6,stuck_after_s=35,
        immobilized_cleanup=true,
        cleanup_delay_s=30,
        cleanup_retry_s=2,
        spawn_timeout_s=15,
        spawn={min_distance_m=120,max_distance_m=350}
    },
    drive={
        sirens_enabled=true,beacons_enabled=true,stability_enabled=true,aggression=1.25,ram_enabled=true,ram_retreat_m=5,ram_speed_kmh=60,ram_reverse_kmh=18,
        cruise_kmh=500,corner_kmh=25,
        obstacle_stop_m=8,max_lead_s=1.5,
        steer_full_angle_rad=0.65,reverse_angle_rad=2.35,
        reverse_throttle=0.25,throttle_gain_mps=4,brake_gain_mps=3
    },
    fleet={
        {id="415",name="XXR (Crusher SWAT)",enabled=true,weight=1},
        {id="416",name="XXR (INFORSER POLICE)",enabled=true,weight=1},
        {id="419",name="XXR (TER 29 POLICE Special Purpose)",enabled=true,weight=1},
        {id="524",name="XXR (VICTORIA GT POLICE)",enabled=true,weight=1},
        {id="550",name="XXR (RS900GTR INTERCEPTOR UNIT)",enabled=true,weight=1},
        {id="551",name="XXR (TER30 POLICE INTERCEPTOR UNIT)",enabled=true,weight=1},
        {id="560",name="XXR (E30GTS A.R.T)",enabled=true,weight=1},
        {id="564",name="XXR (SPORTFOLS EVO POLICE INTERCEPTOR UNIT)",enabled=true,weight=1},
        {id="569",name="XXR (SPORTFOLS EVO SHERIFF)",enabled=true,weight=1},
        {id="586",name="XXR (TER 29 CROSSOVER POLICE UNIT)",enabled=true,weight=1},
        {id="642",name="XXR (E30 POLICE INTERCEPTOR)",enabled=true,weight=1},
        {id="643",name="XXR (TER 31 POLICE PATROL UNIT)",enabled=true,weight=1},
        {id="644",name="XXR (INRASHER TYPE R POLICE ARMED UNIT)",enabled=true,weight=1},
        {id="650",name="XXR (KUBIX POLICE PATROL UNIT)",enabled=true,weight=1},
        {id="663",name="XXR (TURBINO TURBO POLICE INTERCEPTOR)",enabled=true,weight=1}
    }
}
