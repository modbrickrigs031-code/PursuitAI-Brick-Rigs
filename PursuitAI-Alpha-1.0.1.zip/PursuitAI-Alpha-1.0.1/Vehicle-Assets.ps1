function Get-PursuitVehiclePlan([string]$PackageRoot,[string]$VehicleRoot) {
    $root=[IO.Path]::GetFullPath($VehicleRoot).TrimEnd('\')
    $source=Join-Path $PackageRoot 'assets\Vehicles'
    $result=@()
    foreach($folder in Get-ChildItem -LiteralPath $source -Directory) {
        if($folder.Name -notmatch '^PursuitAI_(415|416|419|524|550|551|560|564|569|586|642|643|644|650|663)$'){throw 'Unexpected vehicle namespace.'}
        $destinationFolder=Join-Path $root $folder.Name
        if((Test-Path -LiteralPath $destinationFolder) -and ((Get-Item -LiteralPath $destinationFolder).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Vehicle destination must not be a junction or symbolic link.'}
        foreach($file in Get-ChildItem -LiteralPath $folder.FullName -File) {
            if($file.Name -notin @('Vehicle.brv','MetaData.brm','Preview.png')){throw ('Unexpected vehicle asset: '+$file.Name)}
            $destination=[IO.Path]::GetFullPath((Join-Path $destinationFolder $file.Name))
            if(-not $destination.StartsWith(($root+'\PursuitAI_'),[StringComparison]::OrdinalIgnoreCase)){throw 'Vehicle destination outside namespace.'}
            if((Test-Path -LiteralPath $destination) -and ((Get-Item -LiteralPath $destination).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Vehicle destination must not be a symbolic link.'}
            $result+=@{source=$file.FullName;target=$destination;asset=$true;relative=('vehicles\'+$folder.Name+'\'+$file.Name);root=$root}
        }
    }
    if($result.Count -ne 45){throw 'Expected all 45 vehicle assets.'}
    return $result
}
